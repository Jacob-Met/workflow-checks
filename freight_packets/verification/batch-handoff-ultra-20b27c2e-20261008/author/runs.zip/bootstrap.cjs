const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto');
const root=process.argv[2], packet=JSON.parse(fs.readFileSync(p.join(root,'source-payload.json'),'utf8'));
const sha=(b)=>c.createHash('sha256').update(b).digest('hex');
const blob=(b)=>c.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
const entries=[];
for(const f of packet.files){
 let bytes=Buffer.from(f.content);
 let corrected=false;
 if(blob(bytes)!==f.sha&&bytes[bytes.length-1]===10&&blob(bytes.subarray(0,-1))===f.sha){bytes=bytes.subarray(0,-1);corrected=true;}
 if(blob(bytes)!==f.sha||bytes.length!==f.size)throw Error('source mismatch '+f.path);
 const target=p.join(root,'baseline',f.path);fs.mkdirSync(p.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});
 entries.push({path:f.path,bytes:bytes.length,sha256:sha(bytes),git_blob:f.sha,transport_extra_lf_removed:corrected});
}
fs.writeFileSync(p.join(root,'baseline-source-manifest.json'),JSON.stringify({repository:packet.repository,base_commit:packet.base_commit,entries},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({verified:entries.length,total_bytes:entries.reduce((s,e)=>s+e.bytes,0),transport_corrections:entries.filter(e=>e.transport_extra_lf_removed).map(e=>e.path),node:process.version}));
