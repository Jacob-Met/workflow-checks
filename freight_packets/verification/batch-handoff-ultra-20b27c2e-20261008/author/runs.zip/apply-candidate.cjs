const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto');
const root=process.argv[2], branch='candidate';
fs.cpSync(p.join(root,'baseline'),p.join(root,branch),{recursive:true,errorOnExist:true,force:false});
const files=JSON.parse(fs.readFileSync(p.join(root,'candidate-delta.json'),'utf8'));
for(const row of files){
 const b=Buffer.from(row.content);const sha=c.createHash('sha256').update(b).digest('hex');
 if(b.length!==row.size||sha!==row.sha256)throw Error(row.path);
 const target=p.join(root,branch,row.path);fs.mkdirSync(p.dirname(target),{recursive:true});fs.writeFileSync(target,b);
}
const pins=files.map(({content,...row})=>row);
fs.writeFileSync(p.join(root,'candidate-source-pins.json'),JSON.stringify(pins,null,2)+'\n');
console.log(JSON.stringify({verified_delta:files.length,bytes:files.reduce((n,f)=>n+f.size,0)}));
