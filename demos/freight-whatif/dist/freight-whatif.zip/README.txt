FREIGHT WHAT-IF / WORKFLOW CHECKS

Synthetic freight reviewer demo. All scenarios are invented.
No third-party packages, external services or API keys are required.

RUN
1. Extract this ZIP into a new directory.
2. From that directory, run: python3 tools/serve.py
3. Open http://127.0.0.1:8765/
4. Press Ctrl-C in the terminal to stop the server.
   Use --port 8877 if 8765 is already occupied.

Use a local HTTP server; opening index.html directly as file:// will not
load JavaScript modules in browsers.

INSTALL / VERIFY / ROLLBACK (optional)
python3 tools/install.py install --target /your/new/freight-site
python3 tools/install.py verify --target /your/new/freight-site
python3 tools/serve.py --site /your/new/freight-site
Stop the server, then:
python3 tools/install.py rollback --target /your/new/freight-site

The installer creates a NEW target. It never overwrites an existing one.
Rollback refuses edited content, extra files or symlinks. Leave those intact
and review them yourself rather than deleting another person's work.

WHAT IT DOES
Four authored cases; editable timing, detention terms and invoice charges.
Findings include exact reasons and scenario evidence pointers.
Download records contain the loaded baseline, current inputs/results and
canonical rule source pins. Invalid inputs pause the review and download.
An evidence exception is shown as no automatic claim.

SCOPE
One brokered stop, one same-row arrival/departure pair, one known rate con,
one invoice. Civil minute times, USD integer cents. Not a live carrier tool,
payment approval or settlement engine. Duplicate invoices, missing rate
confirmations, multi-stop matching, fines and settlement are outside scope.
Edits remain in page memory and reset on refresh. Use Download record to save
them. Open saved record checks that existing v1 JSON and previews all sixteen
inputs before explicit replacement. Cancel keeps the current draft. Records
are limited to 1 MiB UTF-8 and must match this demo's pinned rules and preset;
saved calculations are checked against fresh results, not trusted as authority.

SOURCE AND VERIFICATION
https://github.com/Jacob-Met/workflow-checks/issues/17
Source, actual-Python parity oracle, browser receiving and install receipts:
demos/freight-whatif/ in the workflow-checks repository.
manifest.json pins every file in this archive and the canonical rule source.
