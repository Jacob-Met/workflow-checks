from __future__ import annotations
import contextlib,copy,datetime,hashlib,http.client,json,os,pathlib,shutil,sys,threading,traceback
from unittest import mock
root=pathlib.Path("/tmp/hamon-utility-evidence-independent-68094585a1c2")
run=root/"candidate-receiving-v1";run.mkdir()
temp=run/"private-temporary";temp.mkdir()
os.environ["TMPDIR"]=str(temp)
sys.dont_write_bytecode=True
candidate=root/"candidate-source"/"utility_watch"
sys.path.insert(0,str(candidate))
from uwatch import evidence,review,review_desk
from uwatch import review_evidence
baseline=json.loads((root/"original-reference-receipt.json").read_bytes())
controls=json.loads((root/"additional-original-receipt.json").read_bytes())
data=pathlib.Path(baseline["data"]);report=pathlib.Path(baseline["report"])
original_worksheet=pathlib.Path(baseline["worksheet"])
worksheet=run/"selected-worksheet.csv";shutil.copyfile(original_worksheet,worksheet)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pins(directory):return {str(p.relative_to(directory)):sha(p.read_bytes()) for p in directory.rglob("*") if p.is_file()}
before={"original_source":pins(root/"original-source"),"candidate_source":pins(root/"candidate-source"),"original_fixture":pins(root/"original-fixture"),"additional_original_controls":pins(root/"additional-original-controls")}
groups=[];http_records=[];refusals=[];direct_records=[];controller_actions=[]
reference={tuple(e["identity"]):e for e in baseline["references"]}
target=baseline["references"][0]
target_raw=pathlib.Path(target["path"]).read_bytes()
request={"snapshot":baseline["worksheet_snapshot"],"row_id":target["row_id"]}
annotation=controls["annotation_request"]
annotation_raw=(root/"additional-original-controls"/"original-annotation.csv").read_bytes()
def save(name,raw):
 path=run/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
 return {"path":str(path.relative_to(run)),"bytes":len(raw),"sha256":sha(raw)}
def group(name,fn):
 item={"group":name,"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  details=fn();item.update(passed=True,details=details)
 except Exception as exc:
  log=traceback.format_exc();save(name+".traceback.txt",log.encode())
  item.update(passed=False,error=type(exc).__name__+": "+str(exc))
 groups.append(item)
 (run/"groups-progress.json").write_text(json.dumps(groups,indent=2)+"\n")
 print(json.dumps(item),flush=True)
def refusal(label,fn):
 try:fn()
 except ValueError as exc:
  refusals.append({"name":label,"type":type(exc).__name__,"message":str(exc)})
  return
 raise AssertionError(label+" unexpectedly returned evidence")
@contextlib.contextmanager
def server_for(path,source=data):
 with review_desk.DeskServer(path,port=0,data=source,report=report) as server:
  thread=threading.Thread(target=lambda:server.serve_forever(poll_interval=0.01),daemon=True)
  thread.start()
  try:yield server
  finally:server.shutdown();thread.join(5)
def http(server,label,path="/api/evidence",payload=None,method="POST",token=True):
 connection=http.client.HTTPConnection("127.0.0.1",server.server_port,timeout=30)
 headers={"Host":server.host,"Origin":server.origin}
 if token:headers["X-Review-Token"]=server.token
 raw=json.dumps(payload,separators=(",",":")).encode() if payload is not None else None
 if raw is not None:headers["Content-Type"]="application/json"
 try:
  connection.request(method,path,body=raw,headers=headers)
  response=connection.getresponse();body=response.read();status=response.status
  record={"label":label,"method":method,"path":path,"status":status,"content_type":response.getheader("Content-Type"),"request":payload,"response":save("http/"+label+".body",body)}
  http_records.append(record)
  return status,body
 finally:connection.close()
def inspect_exact(desk,entry,source,label):
 req={"snapshot":desk.snapshot,"row_id":entry["row_id"]}
 expected=pathlib.Path(entry["path"]).read_bytes()
 raw=desk.inspect(req,data=source,report=report)
 if raw!=expected:raise AssertionError(label+" changed original native JSON bytes")
 direct_records.append({"label":label,**save("direct/"+label+".json",raw)})
 return raw
def literal_identity():
 desk=review_desk.DeskSnapshot(worksheet)
 if desk.download(annotation)!=annotation_raw:raise AssertionError("original annotation download changed before inspection")
 with server_for(worksheet) as server:
  status,view_raw=http(server,"worksheet",path="/api/worksheet",method="GET")
  view=json.loads(view_raw)
  assert status==200 and view["snapshot"]==desk.snapshot and view["source_evidence"] is True
  for index,entry in enumerate(baseline["references"]):
   raw=inspect_exact(desk,entry,data,"reference-"+str(index))
   row=desk.current[entry["row_id"]]
   adapter=review_evidence.inspect_evidence(data,report,row,desk.view()["metadata"])
   assert adapter==raw
   status,received=http(server,"reference-"+str(index),payload={"snapshot":desk.snapshot,"row_id":entry["row_id"]})
   assert status==200 and received==raw
   doc=json.loads(received)
   assert [r["pointer"] for r in doc["records"]]==doc["finding"]["evidence"]
   if entry["identity"][1]=="B-001":
    assert all(r["fields"].get("account_no")=="B-001" for r in doc["records"])
   else:assert doc["records"][0]["record_end_line"]==3
 if desk.download(annotation)!=annotation_raw:raise AssertionError("annotation download changed after inspection")
 return {"references":len(baseline["references"]),"exact_original_annotation_sha256":sha(annotation_raw)}
def snapshot_and_annotations():
 desk=review_desk.DeskSnapshot(worksheet)
 tests=[
 ("wrong-snapshot",{"snapshot":"0"*64,"row_id":target["row_id"]}),
 ("unknown-row",{"snapshot":desk.snapshot,"row_id":"f"*32}),
 ("extra-field",{**request,"path":"ignored.json"}),
 ("nontext-row",{"snapshot":desk.snapshot,"row_id":True})]
 for label,payload in tests:refusal(label,lambda payload=payload:desk.inspect(payload,data=data,report=report))
 refusal("unconfigured",lambda:desk.inspect(request,data=None,report=None))
 for name in ["history","annotation-only"]:
  e=next(x for x in controls["variants"] if x["name"]==name)
  other=review_desk.DeskSnapshot(pathlib.Path(e["path"]))
  req={"snapshot":e["snapshot"],"row_id":e["row_id"]}
  if name=="history":refusal(name,lambda:other.inspect(req,data=data,report=report))
  else:assert other.inspect(req,data=data,report=report)==target_raw
 with server_for(worksheet) as server:
  status,_=http(server,"missing-token",payload=request,token=False);assert status==403
  status,_=http(server,"wrong-snapshot",payload=tests[0][1]);assert status==409
  status,_=http(server,"extra-field",payload=tests[2][1]);assert 400<=status<500
  status,raw=http(server,"annotations-after-refusal",path="/api/download",payload=annotation)
  assert status==200 and raw==annotation_raw
 return {"direct_refusals":6,"HTTP_annotation_download_preserved":True}
def resealed_fields():
 cases=[e for e in controls["variants"] if e["name"] not in ("history","annotation-only")]
 for e in cases:
  desk=review_desk.DeskSnapshot(pathlib.Path(e["path"]))
  assert e["original_admitted"] and desk.snapshot==e["snapshot"]
  payload={"snapshot":e["snapshot"],"row_id":e["row_id"]}
  refusal("resealed-"+e["name"],lambda desk=desk,payload=payload:desk.inspect(payload,data=data,report=report))
 e=next(x for x in cases if x["name"]=="pointer-other-account")
 with server_for(pathlib.Path(e["path"])) as server:
  status,raw=http(server,"resealed-other-account",payload={"snapshot":e["snapshot"],"row_id":e["row_id"]})
  assert 400<=status<500
  assert "records" not in json.loads(raw)
 return {"original_checksum_valid_variants_refused":len(cases)}
def after_publish_change():
 race=run/"race-worksheet.csv";shutil.copyfile(original_worksheet,race)
 original=race.read_bytes();desk=review_desk.DeskSnapshot(race)
 rows=copy.deepcopy(desk.rows)
 for row in rows:
  if row["row_id"]==target["row_id"]:row["note"]="Owned receiver changed this after actual native publication"
 changed=review_desk._serialize(rows)
 review._previous(changed)
 called=[]
 actual_publish=evidence._publish
 def publish_then_change(path,raw,recheck):
  actual_publish(path,raw,recheck)
  called.append({"published_bytes":len(raw),"published_sha256":sha(raw)})
  race.write_bytes(changed)
  controller_actions.append({"action":"change_owned_worksheet_after_real_native_publish","before":sha(original),"during":sha(changed)})
 with server_for(race) as server:
  try:
   with mock.patch.object(evidence,"_publish",side_effect=publish_then_change):
    status,body=http(server,"after-real-publish-refusal",payload=request)
   assert len(called)==1 and status==409
   assert "records" not in json.loads(body)
  finally:
   race.write_bytes(original)
   controller_actions.append({"action":"restore_exact_owned_worksheet","sha256":sha(original)})
  status,raw=http(server,"after-real-publish-retry",payload=request)
  assert status==200 and raw==target_raw
 return {"actual_native_publish":called,"HTTP_refused_before_return":True,"retry_exact":True}
def literal_refresh():
 mutable=run/"mutable-data";mutable.mkdir()
 for p in data.iterdir():
  if p.is_file():shutil.copyfile(p,mutable/p.name)
 bill=mutable/"bills.csv";old=bill.read_bytes()
 changed=(pathlib.Path(controls["literal_refresh"]["data"])/"bills.csv").read_bytes()
 expected=pathlib.Path(controls["literal_refresh"]["path"]).read_bytes()
 assert expected!=target_raw and old!=changed
 with server_for(worksheet,mutable) as server:
  status,raw=http(server,"literal-before",payload=request);assert status==200 and raw==target_raw
  try:
   bill.write_bytes(changed)
   controller_actions.append({"action":"publish_owned_logically_equal_literal_CSV","before":sha(old),"after":sha(changed)})
   status,raw=http(server,"literal-after",payload=request)
   assert status==200 and raw==expected
   doc=json.loads(raw);prior=json.loads(target_raw)
   assert doc["finding"]==prior["finding"]
   assert doc["records"][0]["fields"]["memo"]=="   "+prior["records"][0]["fields"]["memo"]
  finally:bill.write_bytes(old)
  status,raw=http(server,"literal-restored",payload=request);assert status==200 and raw==target_raw
 return {"exact_refreshed_bytes":len(expected),"sha256":sha(expected),"native_finding_identity_retained":True}
group("native_literal_identity",literal_identity)
group("current_snapshot_and_annotation_custody",snapshot_and_annotations)
group("resealed_worksheet_fields",resealed_fields)
group("after_native_writer_file_change",after_publish_change)
group("logical_identity_literal_refresh",literal_refresh)
after={"original_source":pins(root/"original-source"),"candidate_source":pins(root/"candidate-source"),"original_fixture":pins(root/"original-fixture"),"additional_original_controls":pins(root/"additional-original-controls")}
preserved=before==after
receipt={"format":"utility-source-records-independent-receipt/1","actor":"chatgpt:68094585a1c2 / root","completed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"state":"passed" if preserved and all(g["passed"] for g in groups) else "failed","python":sys.version,"contract_sha256":sha((root/"contract-before-candidate.json").read_bytes()),"receiver_sha256":sha(pathlib.Path(__file__).read_bytes()),"original_reference_receipt_sha256":sha((root/"original-reference-receipt.json").read_bytes()),"additional_original_receipt_sha256":sha((root/"additional-original-receipt.json").read_bytes()),"groups":groups,"http":http_records,"direct_results":direct_records,"refusals":refusals,"intentional_controller_actions":controller_actions,"source_and_original_inputs_preserved":preserved,"before":before,"after":after,"author_tests_read":False,"author_suite_run":False,"new_browser_process":False}
encoded=(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n").encode()
(run/"receipt.json").write_bytes(encoded)
print(json.dumps({"kind":"utility-root-independent-result","state":receipt["state"],"groups":len(groups),"passed":sum(g["passed"] for g in groups),"http_requests":len(http_records),"direct_refusals":len(refusals),"inputs_preserved":preserved,"receipt_sha256":sha(encoded),"receipt":str(run/"receipt.json")}),flush=True)
raise SystemExit(0 if receipt["state"]=="passed" else 1)
