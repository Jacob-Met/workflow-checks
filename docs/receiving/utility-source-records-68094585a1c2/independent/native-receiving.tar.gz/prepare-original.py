from __future__ import annotations
import csv,io,json,hashlib,os,pathlib,subprocess,sys,datetime
root=pathlib.Path("/tmp/hamon-utility-evidence-independent-68094585a1c2")
original=root/"original-source"/"utility_watch"
work=root/"original-fixture"
work.mkdir()
data=work/"data";data.mkdir()
results=work/"results";results.mkdir()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def write_csv(name,fields,rows,bom=False):
 s=io.StringIO(newline="")
 writer=csv.writer(s,lineterminator="\r\n")
 writer.writerow(fields);writer.writerows(rows)
 raw=s.getvalue().encode("utf-8")
 if bom:raw=bytes([239,187,191])+raw
 (data/name).write_bytes(raw)
write_csv("accounts.csv",["memo","account_no","property","utility","vendor","scope","unit","cycle"],[
 ["  literal <i>A</i> β  ","A-001","Fixture Court A","electric","Example Vendor","common","","monthly"],
 ["  literal B  ","B-001","Fixture Court B","electric","Example Vendor","common","","monthly"]])
write_csv("bills.csv",["memo","bill_id","account_no","vendor_invoice_no","period_start","period_end","usage","usage_unit","amount","late_fee","prior_balance","due_date","received_date"],[
 ["  =SUM(1,2)\r\nliteral βU0001f600\t  ","SHARED-BILL","A-001","INV-SHARED","2026-05-01","2026-05-31"," 10.0000 "," kWh "," 050.000 "," 2.00 "," 0 ","2026-06-15","2026-06-01"],
 ["  B's independent bill  ","SHARED-BILL","B-001","INV-SHARED","2026-05-01","2026-05-31","20","kWh","70","3","0","2026-06-15","2026-06-01"]],bom=True)
write_csv("occupancy.csv",["property","unit","status","from","to"],[])
write_csv("payments.csv",["memo","payment_id","account_no","vendor_invoice_no","amount","paid_date"],[
 [" =1+2\t ","PAY-A","A-001","INV-SHARED","25","2026-06-10"],
 ["B literal","PAY-B","B-001","INV-SHARED","70","2026-06-10"]])
env={**os.environ,"PYTHONPATH":str(original),"PYTHONDONTWRITEBYTECODE":"1"}
commands=[]
def run(label,args):
 proc=subprocess.run([sys.executable,"-m","uwatch",*args],cwd=original,env=env,capture_output=True,timeout=60)
 (results/(label+".stdout")).write_bytes(proc.stdout)
 (results/(label+".stderr")).write_bytes(proc.stderr)
 item={"label":label,"argv":[sys.executable,"-m","uwatch",*args],"exit":proc.returncode,"stdout_sha256":digest(proc.stdout),"stderr_sha256":digest(proc.stderr)}
 commands.append(item)
 (results/"commands.json").write_text(json.dumps(commands,indent=2)+"\n")
 if proc.returncode:raise RuntimeError(label+" failed: "+proc.stderr.decode(errors="replace"))
run("run",["run","--data",str(data),"--out",str(work/"report"),"--as-of","2026-09-28","--eval-from","2026-03-01"])
summary=work/"report"/"summary.json"
worksheet=work/"worksheet.csv"
run("review",["review","--data",str(data),"--report",str(summary),"--out",str(worksheet)])
sys.dont_write_bytecode=True
sys.path.insert(0,str(original))
from uwatch import review
from uwatch.review_desk import DeskSnapshot
desk=DeskSnapshot(worksheet)
rows=desk.view()["rows"]
required=[("flag","A-001","SHARED-BILL","LATE_FEE_OR_PAST_DUE"),("flag","B-001","SHARED-BILL","LATE_FEE_OR_PAST_DUE"),("flag","A-001","SHARED-BILL","PAYMENT_MISMATCH")]
references=[]
for index,identity in enumerate(required):
 found=[r for r in rows if tuple(r[k] for k in ("kind","account_no","finding_key","code"))==identity]
 if len(found)!=1:raise AssertionError((identity,[(r["kind"],r["account_no"],r["finding_key"],r["code"]) for r in rows]))
 row=found[0];out=results/("reference-"+str(index)+".json")
 run("evidence-"+str(index),["evidence","--data",str(data),"--report",str(summary),"--kind",row["kind"],"--account",row["account_no"],"--key",row["finding_key"],"--code",row["code"],"--out",str(out)])
 raw=out.read_bytes();doc=json.loads(raw)
 references.append({"identity":identity,"row_id":row["row_id"],"row":row,"path":str(out),"bytes":len(raw),"sha256":digest(raw),"records":[{"pointer":v["pointer"],"columns":v["columns"],"fields":v["fields"]} for v in doc["records"]]})
exceptions=[r for r in rows if r["kind"]=="exception" and r["account_no"]=="A-001"]
if exceptions:
 row=exceptions[0];out=results/"reference-exception.json"
 run("evidence-exception",["evidence","--data",str(data),"--report",str(summary),"--kind",row["kind"],"--account",row["account_no"],"--key",row["finding_key"],"--code",row["code"],"--out",str(out)])
 raw=out.read_bytes()
 references.append({"identity":[row[k] for k in ("kind","account_no","finding_key","code")],"row_id":row["row_id"],"row":row,"path":str(out),"bytes":len(raw),"sha256":digest(raw),"records":json.loads(raw)["records"]})
all_files=[x for x in work.rglob("*") if x.is_file()]
pins={str(x.relative_to(work)):{"bytes":x.stat().st_size,"sha256":digest(x.read_bytes())} for x in all_files}
source_pins={str(x.relative_to(original)):digest(x.read_bytes()) for x in original.rglob("*") if x.is_file()}
receipt={"kind":"utility-root-original-reference","created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"contract_sha256":digest((root/"contract-before-candidate.json").read_bytes()),"candidate_read":False,"native_python":sys.version,"source_root":str(original),"data":str(data),"report":str(summary),"worksheet":str(worksheet),"worksheet_snapshot":desk.snapshot,"metadata":desk.view()["metadata"],"native_current_rows":len(rows),"references":references,"commands":commands,"pins":pins,"source_pins":source_pins,"data_provenance":"All four CSV files independently authored here; native client_csv label is a format result, not live user data."}
b=(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n").encode()
(root/"original-reference-receipt.json").write_bytes(b)
print(json.dumps({"kind":receipt["kind"],"receipt_path":str(root/"original-reference-receipt.json"),"receipt_sha256":digest(b),"candidate_read":False,"native_current_rows":len(rows),"references":[{"identity":e["identity"],"bytes":e["bytes"],"sha256":e["sha256"],"records":e["records"]} for e in references],"commands":[{"label":e["label"],"exit":e["exit"]} for e in commands]},ensure_ascii=False))
