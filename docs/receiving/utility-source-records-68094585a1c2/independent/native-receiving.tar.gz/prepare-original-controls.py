import pathlib,json,hashlib,sys,copy,shutil,datetime
root=pathlib.Path("/tmp/hamon-utility-evidence-independent-68094585a1c2")
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/"original-source"/"utility_watch"))
from uwatch import review,evidence
from uwatch.review_desk import DeskSnapshot,_serialize
baseline=json.loads((root/"original-reference-receipt.json").read_bytes())
work=root/"additional-original-controls";work.mkdir()
desk=DeskSnapshot(pathlib.Path(baseline["worksheet"]))
rows=[copy.deepcopy(r) for r in desk.rows if r["row_state"]!="manifest"]
target=baseline["references"][0]["row_id"];payment=baseline["references"][2]["row_id"]
annotation={"snapshot":desk.snapshot,"changes":[{"row_id":target,"review_status":"in_progress","reviewer":"Receiver β","note":"  =literal note\r\nkeep exact  "}]}
(work/"annotation-request.json").write_text(json.dumps(annotation,ensure_ascii=False,indent=2)+"\n")
(work/"original-annotation.csv").write_bytes(desk.download(annotation))
variants=[]
cases=[("property","property","Fictional other property"),("utility","utility","water"),("detail","detail","separately resealed detail"),("version","evidence_version","0"*64),("pointer-other-account","evidence",review._json(["bills.csv:4"])),("row-as-of","as_of","2026-09-27"),("manifest-as-of",None,None),("pointer-order",None,None),("history","row_state","absent"),("annotation-only",None,None)]
for name,field,value in cases:
 modified=copy.deepcopy(rows);row_id=payment if name=="pointer-order" else target
 selected=next(r for r in modified if r["row_id"]==row_id)
 metadata=dict(baseline["metadata"])
 if name=="manifest-as-of":metadata["as_of"]="2026-09-27"
 elif name=="pointer-order":selected["evidence"]=review._json(list(reversed(json.loads(selected["evidence"]))))
 elif name=="annotation-only":selected.update(review_status="reviewed",reviewer="Independent receiver",note="Kept from an earlier review")
 else:selected[field]=value
 modified=[review._seal(r) for r in modified]
 modified.append(review._manifest(modified,metadata))
 raw=_serialize(modified)
 path=work/(name+".csv");path.write_bytes(raw)
 original=DeskSnapshot(path)
 variants.append({"name":name,"path":str(path),"sha256":hashlib.sha256(raw).hexdigest(),"snapshot":original.snapshot,"row_id":row_id,"original_admitted":True,"expected":"accept_native_exact" if name=="annotation-only" else "refuse","metadata":original.view()["metadata"]})
literal=work/"literal-refresh";literal.mkdir();data=literal/"data";data.mkdir()
for path in pathlib.Path(baseline["data"]).iterdir():
 if path.is_file():shutil.copyfile(path,data/path.name)
b=(data/"bills.csv").read_bytes()
old=b"  =SUM(1,2)";new=b"     =SUM(1,2)"
assert b.count(old)==1
(data/"bills.csv").write_bytes(b.replace(old,new,1))
ref=baseline["references"][0];row=ref["row"];out=literal/"native-evidence.json"
evidence.write_evidence(data,pathlib.Path(baseline["report"]),out,kind=row["kind"],account=row["account_no"],key=row["finding_key"],code=row["code"])
old_doc=json.loads(pathlib.Path(ref["path"]).read_bytes());new_doc=json.loads(out.read_bytes())
assert old_doc["finding"]==new_doc["finding"]
assert new_doc["records"][0]["fields"]["memo"]=="   "+old_doc["records"][0]["fields"]["memo"]
assert old_doc["source"]["inputs"]!=new_doc["source"]["inputs"]
result={"kind":"utility-additional-original-controls","created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"candidate_read":False,"variants":variants,"annotation_request":annotation,"annotation_bytes":len((work/"original-annotation.csv").read_bytes()),"annotation_sha256":hashlib.sha256((work/"original-annotation.csv").read_bytes()).hexdigest(),"literal_refresh":{"data":str(data),"path":str(out),"bytes":out.stat().st_size,"sha256":hashlib.sha256(out.read_bytes()).hexdigest(),"same_native_finding":True,"new_literal_prefix_spaces":3},"source_pins":{str(p.relative_to(root/"original-source"/"utility_watch")):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/"original-source"/"utility_watch").rglob("*") if p.is_file()}}
raw=(json.dumps(result,ensure_ascii=False,indent=2)+"\n").encode()
(root/"additional-original-receipt.json").write_bytes(raw)
print(json.dumps({"kind":result["kind"],"receipt_sha256":hashlib.sha256(raw).hexdigest(),"original_admitted_variants":len(variants),"candidate_read":False,"literal_refresh":result["literal_refresh"],"annotation_sha256":result["annotation_sha256"]}))
