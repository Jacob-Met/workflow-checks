import json,hashlib,datetime,tarfile,gzip,shutil
from pathlib import Path
r=Path("/tmp/hamon-utility-evidence-independent-68094585a1c2")
pub=Path("/tmp/hamon-utility-evidence-independent-publication-68094585a1c2")
pub.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(raw):return hashlib.sha1(("blob "+str(len(raw))).encode()+bytes([0])+raw).hexdigest()
def write_new(path,obj):
 with path.open("x",encoding="utf-8",newline="\n") as f:f.write(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
meta=json.loads((r/"receiving-canonical-inputs.json").read_text())
v1=json.loads((r/"candidate-receiving-v1/receipt.json").read_text())
v2=json.loads((r/"candidate-receiving-v2/receipt.json").read_text())
intake=json.loads((r/"candidate-intake.json").read_text())
assert v1["state"]=="failed" and v2["state"]=="passed"
assert v1["source_and_original_inputs_preserved"] and v2["source_and_original_inputs_preserved"]
assert v1["before"]==v1["after"]==v2["before"]==v2["after"]
assert len(v1["refusals"])==14 and len(v1["http"])==0
assert len(v2["groups"])==5 and len(v2["http"])==15
assert v2["prior_receipt_sha256"]==sha(r/"candidate-receiving-v1/receipt.json")
for e in intake["files"]:
 p=r/"candidate-source"/e["path"];raw=p.read_bytes()
 assert len(raw)==e["bytes"] and sha(p)==e["sha256"] and blob(raw)==e["git_blob"],e["path"]
 assert meta["candidate_leaves"][e["path"]]["sha"]==e["git_blob"],e["path"]
expected=dict(meta["current_main_leaves"])
for path in meta["owned"]:expected[path]=meta["candidate_leaves"][path]
assert expected==meta["test_merge_leaves"]
checks=[]
for j in meta["job_logs"]:
 s=j["content"]
 assert meta["summary"]["test_merge"] in s
 for marker in ["113 passed, 108 subtests passed","125 passed, 1 skipped, 45 subtests passed","161 passed, 81 subtests passed"]:assert marker in s
 checks.append({"job_id":j["job_id"],"log_sha256":hashlib.sha256(s.encode()).hexdigest(),"checkout":meta["summary"]["test_merge"],"result":"success"})
review={
 "format":"utility-source-records-root-review/1",
 "actor":"chatgpt:68094585a1c2 / root",
 "author_attribution":"estate-68094585a1c2 / production; continued by chatgpt:68094585a1c2 / utility_production",
 "reviewed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "decision":"accepted for normal expected-head integration",
 "source":meta["summary"],
 "qualification_state":{"implemented":True,"independently_native_qualified":True,"pr_current_composition_hosted_qualified":True,"integrated":False,"installed_or_deployed":False},
 "independence":{"contract_sha256":sha(r/"contract-before-candidate.json"),"contract_frozen_at":"2026-10-08T18:55:59.633706+00:00","original_reference_receipt_sha256":sha(r/"original-reference-receipt.json"),"additional_original_receipt_sha256":sha(r/"additional-original-receipt.json"),"receiver_before_candidate_sha256":sha(r/"receive-candidate.py"),"receiver_frozen_at":"2026-10-08T19:07:06.761451+00:00","candidate_first_access":intake["first_candidate_access"],"runtime_files_pinned_before_execution":len(intake["files"]),"candidate_or_author_test_source_read_before_receiving":False,"author_source_reviewed_only_after_pass":True},
 "independent_execution":{"python":v2["python"],"original_fixture_cli_commands":6,"original_native_reference_cases":4,"completed_groups":v2["groups"],"continuation_http_requests":15,"prior_native_refusals_reused_without_rerun":14,"v1_receipt_sha256":sha(r/"candidate-receiving-v1/receipt.json"),"v2_receipt_sha256":sha(r/"candidate-receiving-v2/receipt.json"),"all_source_and_original_input_pins_preserved":True,"author_suite_rerun":False,"additional_chromium_run":False},
 "preserved_failure":{"kind":"receiver-only import/name collision","v1_exit":1,"product_finding":False,"description":"The frozen receiver function named http shadowed the imported http package. All attempted HTTP groups failed before a request was sent. Fourteen native refusal controls had already passed.","correction":"Import HTTPConnection directly; resume pending HTTP controls in a fresh v2 directory and reuse the completed exact-source native refusals.","correction_record_sha256":sha(r/"receiver-only-correction.json"),"correction_diff_sha256":sha(r/"receiver-only-correction.diff"),"continuation_exit":0},
 "source_review":{
  "new_adapter":"Calls unchanged native evidence.write_evidence in a private request directory; binds nine complete finding fields, ordered pointer arrays and three row/manifest report fields; returns the producer's exact bounded UTF-8 bytes.",
  "desk":"Accepts only a configured source pair and an exact current saved row/snapshot. Original worksheet is checked before and after production. The authenticated route supplies no user-selected filesystem path.",
  "browser":"Uses textContent and original CSV column order, pre-wrap literal strings, generation/selection guards and AbortController. Downloads the preserved response ArrayBuffer without JSON reserialization. Annotation handling and existing boundaries remain.",
  "reviewed_paths":meta["source_pins"],
  "runtime_diff_sha256":sha(r/"post-receiving-source-review.diff"),
  "docs_and_browser_diff_sha256":sha(r/"post-receiving-docs-browser.diff"),
  "source_or_test_correction_requested":False
 },
 "author_packet_receiving":{"exact_native_files_rehashed_against_manifest_and_canonical_git_tree":110,"manifest_sha256":meta["author_publication_manifest_sha256"],"rendered_images_root_inspected":[{"path":"browser/source-records-desktop.png","sha256":"2e5bdef76fa2ed4479c155d72c6ee88231b24e463b6d91de11e9d1ad8724ed5e"},{"path":"browser/source-records-narrow.png","sha256":"a6ba2501154a9b6f1dc8e5478a9920c1c76072f3faf0561c99eb77e79e9e264c"}],"visual_findings":"Both original captures are readable; literal values, source record cards and note fields remain within the desktop and 320px layout."},
 "hosted_receiving":{"run_id":meta["workflow_run"]["id"],"event":meta["workflow_run"]["event"],"conclusion":meta["workflow_run"]["conclusion"],"test_merge_parents":[x["sha"] for x in meta["test_merge_commit"]["parents"]],"jobs":checks,"workflow_change_required":False},
 "limits":["Independent Unicode fixture covers Greek beta and contains the literal ASCII suffix U0001f600; it does not establish astral-code-point coverage.","Native-author and independent qualification are on ThinkPad. Earlier reported Mac attempts have no recovered process/output evidence and do not establish Mac qualification.","Source inspection is a checked native snapshot, not monitoring or an atomic cross-file lock. Whitespace-only logical identity can remain valid while literal fields and raw source hashes refresh.","No installed-device or hosted-app deployment is claimed. This review authorizes source integration through the existing repository gates."]
}
write_new(r/"ROOT-REVIEW.json",review)
readme="""# Utility source records: independent receiving

Root receiver: chatgpt:68094585a1c2. Author source remains attributed to estate-68094585a1c2 / production and its utility_production continuation.

The contract, original native reference outputs, checksum-valid original worksheet variants and receiver were frozen before any candidate implementation or author test was read. The exact candidate is 08af0d16a33d47446f768169cacdbef0dba595af, tree 18387e31ed12c26ee1bd8779b4768445140c6273.

## Accepted evidence

Five independently selected groups passed through the native adapter, saved DeskSnapshot and 15 real loopback HTTP requests. Four original native JSON references were compared byte-for-byte. Controls include two accounts sharing a bill key, header order and physical record-ending lines, preserved literal fields, annotations and historical-row refusal, original-checksum-valid dishonest worksheet metadata and pointer order, worksheet replacement immediately after the real native writer published, and refreshed literal raw data with unchanged logical finding identity.

Fourteen already completed native refusals are received from preserved v1 and were not run again. The source, original inputs and candidate runtime pins are exact before and after both executions. See ROOT-REVIEW.json, candidate-receiving-v1/receipt.json and candidate-receiving-v2/receipt.json after extracting the capsule.

## Preserved receiver failure and continuation

The first receiver failed because its helper named http shadowed the imported standard-library package. It issued no HTTP request; fourteen native refusals had passed. The original source, tracebacks and failed receipt remain. A separate receiver-only import correction resumed pending HTTP controls in v2 without editing the product or its tests. V2 exited zero. These are one qualified receiving effort with a preserved failed observer attempt, not two clean full runs.

## Source and current composition

Only after the independent pass did root inspect the two new modules, complete runtime/document/browser changes, focused native tests and actual author desktop/320px captures. No product finding was identified. All 110 published author files were rehashed against the manifest and canonical Git blobs.

The actual successful PR checkout 5418f0f4992f0f402dbf96d0d56094a775dac77e joins current main 8fe2c9270f487729af9e88f40894e1c4530f2c20 and the unchanged candidate. Its tree f86d733e0dc616125051fbaae8df848525c06eb8 contains 1,387 leaves: the 110 allowed source/evidence paths plus all 1,277 other current-main leaves exactly. Raw Python 3.10 and 3.12 logs each establish Freight 113 tests/108 subtests, PT 125 tests/45 subtests/one skip and Utility 161 tests/81 subtests. Neither the native suite nor Chromium was repeated for this disjoint main advance.

The capsule contains exact original/candidate runtime inputs, original fixtures and reference outputs, both receivers, both receipts, HTTP bodies, narrow correction, source review, complete canonical tree maps and received raw hosted logs. Its manifest hashes every included file except itself. Original Unicode coverage includes beta; the fixture's U0001f600 suffix is literal text, not an emoji. The source snapshot retains the native writer's existing limits; installed deployment and Mac qualification are not claimed.
"""
with (r/"README.md").open("x",encoding="utf-8",newline="\n") as f:f.write(readme)
files=[]
for p in sorted(r.rglob("*")):
 if "__pycache__" in p.parts or p.suffix==".pyc":continue
 assert not p.is_symlink(),str(p)
 if p.is_file() and p.name!="INDEPENDENT-MANIFEST.json":files.append(p)
entries=[]
for p in files:
 raw=p.read_bytes();entries.append({"path":p.relative_to(r).as_posix(),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"blob":blob(raw)})
manifest={"format":"utility-independent-capsule/1","sealed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"actor":"chatgpt:68094585a1c2 / root","hash_excludes":["INDEPENDENT-MANIFEST.json"],"entries":entries}
write_new(r/"INDEPENDENT-MANIFEST.json",manifest)
archive=pub/"native-receiving.tar.gz"
with archive.open("xb") as out:
 with gzip.GzipFile(fileobj=out,mode="wb",mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode="w") as tar:
   for p in files+[r/"INDEPENDENT-MANIFEST.json"]:tar.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
with tarfile.open(archive,"r:gz") as tar:
 members=tar.getmembers()
 assert len(members)==len(entries)+1
 for e in entries:
  raw=tar.extractfile(e["path"]).read()
  assert len(raw)==e["bytes"] and hashlib.sha256(raw).hexdigest()==e["sha256"]
for source,name in [(r/"README.md","README.md"),(r/"ROOT-REVIEW.json","receipt.json"),(r/"INDEPENDENT-MANIFEST.json","manifest.json")]:shutil.copyfile(source,pub/name)
published=[]
for p in sorted(pub.iterdir()):
 raw=p.read_bytes();published.append({"path":p.name,"local_path":str(p),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"blob":blob(raw),"mode":"100644"})
result={"publication_root":str(pub),"archive_members":len(members),"source_commit":meta["summary"]["candidate"],"current_main":meta["summary"]["current_main"],"test_merge":meta["summary"]["test_merge"],"entries":published}
write_new(r/"independent-publication-seal.json",result)
print(json.dumps(result,ensure_ascii=False))
