"""Receive native CSV/CLI decisions for fictional account-local bill IDs."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


HEADERS = {
    "accounts.csv": "account_no property utility vendor scope unit cycle".split(),
    "bills.csv": ("bill_id account_no vendor_invoice_no period_start period_end usage "
                  "usage_unit amount late_fee prior_balance due_date received_date").split(),
    "occupancy.csv": "property unit status from to".split(),
    "payments.csv": "payment_id account_no vendor_invoice_no amount paid_date".split(),
}


def account(key):
    return dict(zip(HEADERS["accounts.csv"],
                    [key, "Fictional property " + key, "electric", "Fictional vendor", "common", "", "monthly"]))


def bill(key, acct, year, *, invoice=None, late_fee="0"):
    return dict(zip(HEADERS["bills.csv"], [
        key, acct, invoice or f"INV-{acct}-{year}", f"{year}-01-01", f"{year}-01-31",
        "300", "kWh", "60", late_fee, "0", f"{year}-02-15", f"{year}-02-01",
    ]))


def cases():
    old = [bill("A-BASE", "A", 2023), bill("B-BASE", "B", 2023)]
    yield "flag_collision", [account("A"), account("B")], old + [
        bill("SAME-ID", "A", 2024, late_fee="5"), bill("SAME-ID", "B", 2024)
    ], [["B", "SAME-ID"]]
    yield "exception_collision", [account("B")], [old[1],
        bill("SAME-ID", "A", 2024), bill("SAME-ID", "B", 2024)
    ], [["B", "SAME-ID"]]
    yield "duplicate_hold_collision", [account("A"), account("B")], old + [
        bill("A-ORIGINAL", "A", 2024, invoice="A-DUP"),
        bill("SAME-ID", "A", 2024, invoice="A-DUP"), bill("SAME-ID", "B", 2024)
    ], [["B", "SAME-ID"]]
    yield "baseline_collision", [account("A"), account("B")], old + [
        bill("A-ORIGINAL", "A", 2024, invoice="A-DUP"),
        bill("B-BASE", "A", 2024, invoice="A-DUP"), bill("B-CURRENT", "B", 2024)
    ], [["B", "B-CURRENT"]]
    yield "both_clean_control", [account("A"), account("B")], old + [
        bill("SAME-ID", "A", 2024), bill("SAME-ID", "B", 2024)
    ], [["A", "SAME-ID"], ["B", "SAME-ID"]]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    temporary = args.out / "tmp"
    temporary.mkdir()
    engine = args.source / "uwatch/engine.py"
    source_before = hashlib.sha256(engine.read_bytes()).hexdigest()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(args.source.resolve()),
               TMPDIR=str(temporary.resolve()))
    records = []
    for name, accounts, bills, expected in cases():
        root = args.out / name
        data = root / "input"
        data.mkdir(parents=True)
        rows = {"accounts.csv": accounts, "bills.csv": bills, "occupancy.csv": [], "payments.csv": []}
        for filename, fields in HEADERS.items():
            with (data / filename).open("x", encoding="utf-8", newline="") as target:
                writer = csv.DictWriter(target, fieldnames=fields, lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows[filename])
        command = [sys.executable, "-B", "-m", "uwatch", "run", "--data", str(data.resolve()),
                   "--out", str((root / "output").resolve()), "--as-of", "2024-02-01", "--eval-from", "2024-01-01"]
        result = subprocess.run(command, env=env, text=True, capture_output=True, check=False)
        (root / "stdout.log").write_text(result.stdout, encoding="utf-8")
        (root / "stderr.log").write_text(result.stderr, encoding="utf-8")
        report_path = root / "output/summary.json"
        report = json.loads(report_path.read_text()) if report_path.exists() else None
        actual = [[x["account_no"], x["bill_id"]] for x in report["payment_queue_detail"]] if report else None
        record = {"case": name, "native_exit": result.returncode, "expected_queue": expected,
                  "actual_queue": actual, "accepted": result.returncode == 0 and actual == expected,
                  "summary": report}
        records.append(record)
        print(json.dumps({key: record[key] for key in ("case", "native_exit", "expected_queue", "actual_queue", "accepted")}))
    source_after = hashlib.sha256(engine.read_bytes()).hexdigest()
    receipt = {"source": str(args.source.resolve()), "engine_sha256_before": source_before,
               "engine_sha256_after": source_after, "source_unchanged": source_before == source_after,
               "method": "Five fictional CSV exports through native python -m uwatch run; no provider or payment action.",
               "passed": sum(x["accepted"] for x in records), "failed": sum(not x["accepted"] for x in records),
               "cases": records}
    (args.out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return int(receipt["failed"] > 0 or not receipt["source_unchanged"])


if __name__ == "__main__":
    raise SystemExit(main())
