# Utility Watch account-specific bill decisions

## Result and scope

The frozen native checker now includes `account_no` whenever it records or tests bill-ID membership for duplicate history, duplicate holds, flags and exceptions. Bill IDs from another account can no longer alter the current account's baseline or payment-approval queue. Same-account duplicate invoice/period handling and both-copy holds remain intact.

Source is `Jacob-Met/workflow-checks` main `65461ca8f6bd636cd85c0086210ccb1e6837fbee`, tree `24e0514dcb28c545dc8414090a5147db79d6ddac`. Original engine blob: `9deb205ad468381ffc91716f0d7ae6ab88d76f2a`; SHA256 `48c968584d0494ee5fb0538fc7d4c685c2cc3128a45c33f57c2079234cdb7775`.

Candidate engine SHA256: `ff0dc3a473235c55639e4373e3b5a4c786a0cd9ae7badd2be9113f39a4efd3d0`; Git blob `b764a1f45ba718b31f7841e2c2f61d16a7fef5e9`. The only code change is inside `check()`. Byte comparison preserves the source before that function and from `run()` onward, including the entire CSV reader, numeric/date parsing, report generation and CLI contract. Other changed files are the new eight-method regression and the two narrow documentation explanations enumerated in `author-receipt.json`.

The source claim is workflow-checks issue25 and HAMON issue140 comment6059818438. Root accepted the bounded scope before editing. The snapshot has no AGENTS.md. Current review worksheet and report owners retain their implementations; their code and output schemas are unchanged. PR24 owns the separate duplicate-column guard in `_rows`, and its merged source must be inherited before publication. Root's freight PR23 is also a required receiving ancestor.

## Original failures and observed correction

`probe_account_keys.py` executes five fictional CSV exports through the real `python -m uwatch run` path. On the exact baseline, all five commands exit successfully, but four account-isolation expectations fail: a different account's flag, unknown-account exception or duplicate hold removes an otherwise eligible bill; a duplicate ID matching another account's historical bill also produces a false `NO_BASELINE`. The control with two clean accounts sharing a bill ID passes. Every input, command output, summary, CSV, audit and HTML report is retained under `evidence/baseline`.

The unchanged carrier passes all five cases on the frozen candidate. The clean control's complete six native output files are byte-identical to baseline. This is a source correction to an existing advisory review workflow; no bill is paid, approved, disputed or sent.

The eight authored regression methods also check both account-processing orders, both members of a held duplicate pair, the existing prior-year/rate/trailing-usage history filters, and current account/invoice payment matching. They retain source-row evidence and same-account holds. The baseline has six failing methods (ten failure records including subtests) and two passing controls. The candidate passes all eight methods in normal and optimized Python. These checks overlap the CLI histories and are not added into one independent-case count.

The four unchanged maintained Utility Watch test modules pass 81 methods on both baseline and candidate. The existing read-only Python environment at `/workspace/scratch/de626312ee85/integration-review/venv/bin/python` supplies pytest9.1.1; no dependency was installed or changed. Each run used its own temporary directory, disabled bytecode/cache output, and pytest's existing passing-temporary cleanup. Full commands, source before/after hashes and logs are in `evidence/retained-native-receipt.json`.

## Evidence and receiving boundary

`source-manifest.json` and `candidate-source-manifest.json` preserve the first source freezes. `retained-support-manifest.json` separately binds the two unchanged native test support files later added to both isolated snapshots. `account-identity.patch` contains only the four declared paths; `author-receipt.json` hashes the source, original/current outputs, logs and preservation checks.

The initial candidate copy was interrupted by shared `/dev/shm` ENOSPC. Its empty staging is retained under `setup-interrupted`; no tests executed during that attempt. A later capacity read permitted the verified copy. A separate missing-pytest prerequisite failure from the default interpreter is recorded there; the known existing environment supplied the real retained test runner. Neither setup failure is relabelled as a runtime test result.

Root is independently receiving the frozen engine through separately authored native CSV, CLI and review-binding controls on the Mac. That result remains separately attributed and pending in this author checkpoint. Current-parent composition, hosted gates and publication are subsequent steps. No frontend, demo, PT, freight, installed service, live portfolio, provider or payment operation is part of this candidate.
