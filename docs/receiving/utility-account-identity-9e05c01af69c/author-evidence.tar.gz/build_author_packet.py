"""Build the immutable authored Utility Watch evidence capsule; no source execution."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
DOCS = Path("docs/receiving/utility-account-identity-9e05c01af69c")
ROOT_FILES = (
    "source-manifest.json", "candidate-source-manifest.json", "retained-support-manifest.json",
    "probe_account_keys.py", "account-identity.patch", "author-receipt.json", "AUTHOR_REVIEW.md",
    "scope.json", "current-parent-admission.json", "source-whitelist-v1.json", "build_author_packet.py",
)
ROOT_DIRS = ("baseline", "candidate", "evidence", "setup-interrupted")


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def selected():
    files = [ROOT / name for name in ROOT_FILES]
    for directory in ROOT_DIRS:
        files.extend(path for path in (ROOT / directory).rglob("*") if path.is_file())
    if any(path.is_symlink() for path in files):
        raise RuntimeError("Unexpected symlink in authored evidence")
    return sorted(set(files), key=lambda path: str(path.relative_to(ROOT)))


def main():
    paths = selected()
    before = {str(path.relative_to(ROOT)): path.read_bytes() for path in paths}
    manifest = [{"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                 "git_blob": blob(raw)} for name, raw in before.items()]
    target = ROOT / "publication-v1" / DOCS
    target.mkdir(parents=True, exist_ok=False)
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0, filename="") as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
            for name, raw in before.items():
                entry = tarfile.TarInfo(name)
                entry.size = len(raw)
                entry.mode = 0o644
                entry.uid = entry.gid = entry.mtime = 0
                archive.addfile(entry, io.BytesIO(raw))
    packet = stream.getvalue()
    with tarfile.open(fileobj=io.BytesIO(packet), mode="r:gz") as archive:
        members = archive.getmembers()
        if [member.name for member in members] != list(before):
            raise RuntimeError("Archive member identity mismatch")
        for member in members:
            if not member.isfile() or archive.extractfile(member).read() != before[member.name]:
                raise RuntimeError("Archive byte readback failed: " + member.name)
    after = {str(path.relative_to(ROOT)): path.read_bytes() for path in selected()}
    if before != after:
        raise RuntimeError("Authored inputs changed during packaging")
    (target / "author-evidence.tar.gz").write_bytes(packet)
    manifest_document = {"format": "regular-file tar.gz; historical tests remain inside archive",
                         "source_inputs_unchanged_during_packaging": True,
                         "archive_member_count": len(manifest), "archive_bytes": len(packet),
                         "archive_sha256": hashlib.sha256(packet).hexdigest(),
                         "archive_git_blob": blob(packet), "all_members_verified_byte_for_byte": True,
                         "files": manifest}
    (target / "evidence-manifest.json").write_text(json.dumps(manifest_document, indent=2) + "\n")
    (target / "author-receipt.json").write_bytes((ROOT / "author-receipt.json").read_bytes())
    readme = """# Utility Watch account-specific bill decisions

This is the immutable authored source and evidence packet for workflow-checks issue25,
from universal-9e05c01af69c / memory_path. Four declared source paths change:
engine.check, its new maintained account-bill regression, README and HARDENING.
The separate CSV-header owner retains engine._rows and its own test.

The checker now scopes duplicate-history exclusions, duplicate holds, flags and
exceptions by account plus bill ID. Same-account duplicate rules remain intact.
A matching exported bill ID on another account cannot remove its baseline or its
otherwise eligible advisory queue entry. Existing result schemas, row evidence,
thresholds and account/invoice payment matching are preserved.

Original source: 65461ca8f6bd636cd85c0086210ccb1e6837fbee.
The four before-images remain exact on freight receiving main
9e931fa9f42033bf2368f7149684fb5631345715, tree0b0c903801f432968e9cdfb1f1fa134cecc37217.
Original engine SHA256: 48c968584d0494ee5fb0538fc7d4c685c2cc3128a45c33f57c2079234cdb7775.
Authored engine SHA256: ff0dc3a473235c55639e4373e3b5a4c786a0cd9ae7badd2be9113f39a4efd3d0.
Any later merged CSV-header source must be preserved in the final receiving composition.

## Authored qualification

- Five actual native CSV/CLI histories: baseline one passes/four fail account isolation;
  candidate five pass. All commands themselves exit0.
- Eight focused native regression methods: baseline six methods fail/two controls pass
  (ten failure records with subtests); candidate eight pass in normal and optimized Python.
- The four unchanged maintained Utility modules pass81 methods on both baseline and candidate.
- All six generated files for the unchanged two-clean-account control are byte-identical.
  These overlapping gates are recorded separately.

Full source, original/current CSV inputs and outputs, raw logs, frozen regression/carrier,
patch, manifests and setup failures are inside author-evidence.tar.gz. Every regular member
is listed and byte-verified in evidence-manifest.json. Historical test sources are enclosed
in the archive and do not add discoverable tests to the repository. The only new maintained
test is utility_watch/tests/test_account_bill_keys.py.

The retained suite used the existing read-only de626312ee85 Python environment with pytest9.1.1;
no dependency installation or environment write occurred. The initial transient ENOSPC copy
failure and default-interpreter missing-pytest setup failure remain explicit historical facts.
Neither is counted as a runtime test.

Independent root receiving, final current-parent composition and hosted gates are separate
records. This authored checkpoint does not claim those pending steps. The unchanged
review.py includes the engine source hash in evidence versions: after an engine upgrade,
a saved annotation can become historical and require a new current review even if rounded
finding text is unchanged. This candidate does not rewrite or waive that existing binding.

All inputs are fictional and local. This source change neither pays nor approves bills,
and makes no live-portfolio, provider, browser, service or deployment claim.
"""
    (target / "README.md").write_text(readme)
    files = []
    for path in sorted((ROOT / "publication-v1").rglob("*")):
        if path.is_file():
            raw = path.read_bytes()
            files.append({"path": str(path.relative_to(ROOT / "publication-v1")),
                          "source_path": str(path), "bytes": len(raw),
                          "sha256": hashlib.sha256(raw).hexdigest(), "git_blob": blob(raw),
                          "mode": "100644", "type": "blob"})
    if len(files) != 8:
        raise RuntimeError("Expected four source paths and four evidence paths")
    receipt = {"repository": "Jacob-Met/workflow-checks", "receiving_commit":
               "9e931fa9f42033bf2368f7149684fb5631345715", "source_whitelist_count": 4,
               "evidence_path_count": 4, "source_publication": "held pending independent root receiving",
               "files": files}
    (ROOT / "publication-manifest-v1.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"files": len(files), "source_whitelist": 4, "evidence_files": 4,
                      "archive_members": len(manifest), "archive_bytes": len(packet),
                      "archive_sha256": manifest_document["archive_sha256"],
                      "manifest_sha256": hashlib.sha256((ROOT / "publication-manifest-v1.json").read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
