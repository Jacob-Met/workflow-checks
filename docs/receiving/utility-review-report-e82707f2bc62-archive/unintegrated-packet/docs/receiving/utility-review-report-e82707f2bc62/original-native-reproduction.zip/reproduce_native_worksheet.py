"""Create a fictional, genuinely reconciled worksheet through the existing CLI."""
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def write_csv(path, columns, rows):
    with path.open("w", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=columns, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def create_fixture(root: Path, source: Path):
    data = root / "data"
    data.mkdir(parents=True)
    accounts = [dict(account_no=key, property="Fictional Courtyard (synthetic)",
                     utility="gas", vendor="Placeholder Gas", scope="common", unit="", cycle="monthly")
                for key in ("SYN-A", "SYN-B", "SYN-C")]
    write_csv(data / "accounts.csv", list(accounts[0]), accounts)
    bills = []
    for account in accounts:
        for year in (2025, 2026):
            key = account["account_no"]
            bills.append(dict(bill_id=f"{key}-{year}", account_no=key,
                              vendor_invoice_no=f"INV-{key}-{year}",
                              period_start=f"{year}-09-01", period_end=f"{year}-09-30",
                              usage="100", usage_unit="therm", amount="100", late_fee="1" if year == 2026 else "0",
                              prior_balance="0", due_date=f"{year}-10-25", received_date=f"{year}-10-01"))
    write_csv(data / "bills.csv", list(bills[0]), bills)
    write_csv(data / "occupancy.csv", ["property", "unit", "status", "from", "to"], [])
    write_csv(data / "payments.csv", ["payment_id", "account_no", "vendor_invoice_no", "amount", "paid_date"], [])
    (data / "expected.json").write_text(json.dumps({"as_of": "2026-10-05", "eval_from": "2026-09-01",
                                                  "fixture": "authored fictional review-report scenario"}))
    env = dict(os.environ, PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE="1")
    commands = []

    def cli(*args):
        process = subprocess.run([sys.executable, "-B", "-m", "uwatch", *map(str, args)], env=env,
                                 cwd=source, capture_output=True, text=True, timeout=30)
        commands.append({"args": list(map(str, args)), "returncode": process.returncode,
                         "stdout": process.stdout, "stderr": process.stderr})
        if process.returncode:
            raise AssertionError(commands[-1])

    report = root / "reports"
    cli("run", "--data", data, "--out", report, "--as-of", "2026-10-05", "--eval-from", "2026-09-01")
    first = root / "review-1.csv"
    cli("review", "--data", data, "--report", report / "summary.json", "--out", first)
    with first.open(encoding="utf-8", newline="") as src:
        reader = csv.DictReader(src)
        columns, rows = reader.fieldnames, list(reader)
    assert len(rows) == 4, rows
    for row in rows:
        if row["row_state"] == "manifest":
            continue
        row["review_status"] = "reviewed" if row["account_no"] != "SYN-C" else "in_progress"
        row["reviewer"] = "Alex & Co" if row["account_no"] == "SYN-A" else "Blair"
        row["note"] = "Called placeholder vendor, reference 17.\nSecond line: <b>literal only</b>."
    write_csv(first, columns, rows)
    for bill in bills:
        if bill["bill_id"] == "SYN-B-2026":
            bill["late_fee"] = "2"
        if bill["bill_id"] == "SYN-C-2026":
            bill["late_fee"] = "0"
    write_csv(data / "bills.csv", list(bills[0]), bills)
    cli("run", "--data", data, "--out", report, "--as-of", "2026-10-05", "--eval-from", "2026-09-01")
    second = root / "review-2.csv"
    cli("review", "--data", data, "--report", report / "summary.json", "--previous", first, "--out", second)
    with second.open(encoding="utf-8", newline="") as src:
        final_rows = list(csv.DictReader(src))
    assert [r["row_state"] for r in final_rows] == ["current", "current", "changed", "absent", "manifest"], final_rows
    return second, commands


def main():
    root = Path(__file__).resolve().parent
    source = root / "baseline" / "utility_watch"
    receiving = root / "baseline-reproduction"
    receiving.mkdir()
    worksheet, commands = create_fixture(receiving, source)
    before = hashlib.sha256(worksheet.read_bytes()).hexdigest()
    process = subprocess.run([sys.executable, "-B", "-m", "uwatch", "review-report", "--worksheet", str(worksheet),
                              "--out", str(receiving / "review.html")], cwd=source,
                             env=dict(os.environ, PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE="1"),
                             capture_output=True, text=True, timeout=30)
    receipt = {"source": "9e931fa9f42033bf2368f7149684fb5631345715", "native_existing_commands": commands,
               "new_command": {"returncode": process.returncode, "stdout": process.stdout, "stderr": process.stderr},
               "worksheet_sha256": before, "worksheet_unchanged": before == hashlib.sha256(worksheet.read_bytes()).hexdigest(),
               "html_created": (receiving / "review.html").exists(),
               "meaning": "Four native commands retain two current findings plus changed/absent reviewed history; no readable annotated-report command exists."}
    (receiving / "receiving.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
