import os,json,time,pathlib,signal,hashlib
leader=1599741
profile="/home/jacob/hamon-freight-browser-cd1df0f1ee24/attempt1/profile"
expected={1599741:85931537,1605074:85934818,1605077:85934821,1605117:85934849,1605315:85934909,1605398:85934946,1605608:85935113,1606336:85935436,1606379:85935467,1607029:85935819}
out=pathlib.Path("/dev/shm/hamon-freight-receiving-cd1df0f1ee24/browser-native/cleanup-attempt1-v1")
out.mkdir(exist_ok=False)
hz=os.sysconf("SC_CLK_TCK")
boot=int(next(x.split()[1] for x in pathlib.Path("/proc/stat").read_text().splitlines() if x.startswith("btime ")))
def info(pid):
 try:
  p=pathlib.Path("/proc")/str(pid); raw=(p/"stat").read_text(); end=raw.rfind(")"); a=raw[end+2:].split()
  cmd=(p/"cmdline").read_bytes().split(b"\0")
  return {"pid":pid,"comm":raw[raw.find("(")+1:end],"state":a[0],"ppid":int(a[1]),"pgid":int(a[2]),"sid":int(a[3]),"start_ticks":int(a[19]),"start_unix":boot+int(a[19])/hz,"exact_profile":("--user-data-dir="+profile).encode() in cmd}
 except (OSError,ValueError,IndexError): return None
def members():
 return [d for p in pathlib.Path("/proc").iterdir() if p.name.isdigit() for d in [info(int(p.name))] if d and d["pgid"]==leader]
def owned(rows):
 return all(r["pid"] in expected and r["start_ticks"]==expected[r["pid"]] and r["comm"]=="chrome" and r["pgid"]==leader and r["sid"]==leader for r in rows)
def artifacts():
 base=out.parent/"attempt1-process"
 return {p.name:{"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in base.iterdir() if p.is_file()}
def save(name,data):
 b=(json.dumps(data,indent=2)+"\n").encode(); (out/name).write_bytes(b); return {"path":str(out/name),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
before=members(); l=info(leader)
receipt={"kind":"authorized-owned-orphan-cleanup-only","started_unix":time.time(),"product_retry":False,"profile_path":profile,"expected_leader_start_ticks":expected[leader],"before":before,"evidence_before":artifacts(),"signals":[],"scope":"Exact preobserved Chrome group only; no files deleted"}
save("before.json",receipt)
try:
 assert l and l["exact_profile"] and l["start_ticks"]==expected[leader] and l["pgid"]==leader and l["sid"]==leader
 assert 1791493289.3401258 <= l["start_unix"] <= 1791493350
 assert owned(before) and {r["pid"] for r in before}==set(expected)
 # Revalidate all observed identities and the exact leader profile immediately before TERM.
 now=members(); fresh=info(leader)
 assert owned(now) and fresh and fresh["exact_profile"] and fresh["start_ticks"]==expected[leader]
 receipt["signals"].append({"signal":"SIGTERM","pgid":leader,"at_unix":time.time(),"verified_members":now})
 os.killpg(leader,signal.SIGTERM)
 deadline=time.monotonic()+9
 while time.monotonic()<deadline:
  current=members()
  if not any(r["state"]!="Z" for r in current): break
  time.sleep(.2)
 current=members(); live=[r for r in current if r["state"]!="Z"]
 if live:
  assert owned(current),"Ownership changed after TERM; refusing further signals"
  receipt["signals"].append({"signal":"SIGKILL","pgid":leader,"at_unix":time.time(),"verified_members":current})
  os.killpg(leader,signal.SIGKILL)
  time.sleep(.5)
 receipt["after"]=members()
 receipt["live_owned_processes_remaining"]=[r for r in receipt["after"] if r["state"]!="Z"]
 receipt["zombie_entries_remaining"]=[r for r in receipt["after"] if r["state"]=="Z"]
 receipt["completed"]=not receipt["live_owned_processes_remaining"]
except BaseException as e:
 receipt["error"]=repr(e); receipt["after"]=members(); receipt["completed"]=False
receipt["ended_unix"]=time.time()
receipt["profile_preserved"]=pathlib.Path(profile).is_dir()
receipt["evidence_after"]=artifacts()
receipt["original_evidence_unchanged"]=receipt["evidence_before"]==receipt["evidence_after"]
meta=save("cleanup-receipt.json",receipt)
print(json.dumps({"receipt":meta,"completed":receipt["completed"],"signals":[s["signal"] for s in receipt["signals"]],"after":receipt["after"],"profile_preserved":receipt["profile_preserved"],"original_evidence_unchanged":receipt["original_evidence_unchanged"],"error":receipt.get("error")},indent=2))
