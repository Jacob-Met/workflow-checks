# Freight saved-record browser receiving

The maintained receiver is `browser-receiver-v4.mjs` (to be published as `demos/freight-whatif/tests/scenario-record-browser.mjs`). It uses an existing Node, Puppeteer-core and Chromium installation; it installs nothing. The receiver starts one private loopback HTTP server and one headless browser with a fresh caller-chosen output/profile directory. Chromium's sandbox remains enabled.

Run it with a JSON configuration:

```sh
node demos/freight-whatif/tests/scenario-record-browser.mjs /absolute/path/config.json
```

The configuration names `chromiumPath`, `puppeteerPath`, `runRoot`, `baselineRoot`, `candidateRoot`, `sourcePins`, `fixturePins`, `launchTimeoutMs` and `totalTimeoutMs`. Set `authorizedCandidateFreeze: true` only after filling and checking the immutable source/fixture pins. The output directory must be an absolute normalized path that does not exist; this prevents profile reuse and overwriting earlier evidence. The pre-run sample `config-unfrozen-v1.json` intentionally refuses execution.

Each source pin is `{path, sha256, route}`, where route is `baseline` or `candidate`. Serve exactly the original five site files from commit `39ea75b0da2a7c3463e426dd32ba52860966cae4`, and the candidate's six site files (including `scenario-record.mjs`). Original Git blob identities are recorded in `baseline-source-manifest.json`. No source is fetched during the browser test. The exact original app performs the initial Download, so this checks compatibility with a real pre-feature record.

Each fixture pin is `{name, path, sha256}`. The eight names used here are `accept-preset-within-free.json`, `reject-truncated-json.json`, `reject-current-amount.json`, `accept-literal-filename.json`, `accept-null-cap.json`, `accept-zero-header.json`, `accept-missing-pod.json` and `accept-incomplete-ratecon.json`. They are unchanged members of the independent pre-implementation fixture packet. Coherent fixture results came from the unchanged original model; the $1,900/$1,910 invoice and zero-detention checks are separate hand-derived expectations.

The receiver records 17 groups from `browser-contract-v1.json`, actual browser downloads, page/request errors, source/config/fixture preservation, and desktop/narrow captures. A group failure is retained while later groups continue when possible. `pass` requires all 17 groups, source preservation and clean browser closure. A screenshot is marked `visuallyInspected: false` until a separate human/model inspection receipt is added; merely creating a PNG is not visual acceptance.

Puppeteer intercepts the browser's file chooser and supplies actual selected files. In the installed Puppeteer 25 route, `FileChooser.cancel()` dispatches an untrusted bubbling DOM `cancel` event on the input. That qualifies the application's cancel listener, not an OS-picker gesture. Deferred `File.prototype.text` promises control race delivery only; actual fixture bytes and acceptance expectations remain unchanged. Natural reads are awaited after their observed change event, preventing premature negative-state assertions.

The optional `run-browser-v1.py` is the qualification lane's bounded process supervisor. It captures raw stdout/stderr, explicit exit status and input hashes; its resource checks are specific to the recorded native host. It is not needed to use the portable Node receiver.

Versions v1-v3 were never executed against the product. Their exact source and review deltas remain in this packet. Prior Probability Chromium startup failures remain separate evidence and are not relabeled by a later Freight result.
