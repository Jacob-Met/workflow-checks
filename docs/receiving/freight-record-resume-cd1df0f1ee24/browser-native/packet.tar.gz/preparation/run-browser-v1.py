#!/usr/bin/env python3
"""Bounded receiving process wrapper. It starts only its supplied browser driver."""
import hashlib, json, os, pathlib, signal, subprocess, sys, time
driver, config, process_dir = map(pathlib.Path, sys.argv[1:4])
process_dir.mkdir(parents=True, exist_ok=False)
cfg = json.loads(config.read_text())
assert cfg["authorizedCandidateFreeze"] is True
for volume, minimum in [(pathlib.Path("/home/jacob"), 200 * 1024 * 1024), (process_dir, 20 * 1024 * 1024)]:
    stat = os.statvfs(volume)
    assert stat.f_bavail * stat.f_frsize >= minimum, ("insufficient receiving capacity", str(volume))
pins = [{"path": str(p), "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in [driver, config]]
receipt = {"command": ["/usr/bin/node", str(driver), str(config)], "started_unix": time.time(), "input_pins": pins, "timeout_seconds": 255, "process_group_owned": True, "automatic_retry": False}
(process_dir / "preflight.json").write_text(json.dumps(receipt, indent=2) + "\n")
with (process_dir / "stdout.log").open("wb") as stdout, (process_dir / "stderr.log").open("wb") as stderr:
    process = subprocess.Popen(receipt["command"], stdout=stdout, stderr=stderr, start_new_session=True)
    receipt["pid"] = process.pid
    (process_dir / "process-start.json").write_text(json.dumps(receipt, indent=2) + "\n")
    try:
        receipt["exit_code"] = process.wait(timeout=255)
        receipt["timed_out"] = False
    except subprocess.TimeoutExpired:
        receipt["timed_out"] = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            receipt["exit_code"] = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            receipt["exit_code"] = process.wait(timeout=5)
receipt["ended_unix"] = time.time()
receipt["duration_seconds"] = receipt["ended_unix"] - receipt["started_unix"]
receipt["input_unchanged"] = all(hashlib.sha256(pathlib.Path(p["path"]).read_bytes()).hexdigest() == p["sha256"] for p in pins)
receipt["logs"] = [{"path": str(process_dir / name), "bytes": (process_dir / name).stat().st_size, "sha256": hashlib.sha256((process_dir / name).read_bytes()).hexdigest()} for name in ["stdout.log", "stderr.log"]]
browser_receipt = pathlib.Path(cfg["runRoot"]) / "browser-receipt.json"
if browser_receipt.exists():
    data = json.loads(browser_receipt.read_text())
    receipt["browser_summary"] = {k: data.get(k) for k in ["pass", "completed", "sourceUnchanged", "browserClosed", "fatal"]}
    receipt["browser_summary"]["groups"] = [{"id": x["id"], "pass": x.get("pass"), "error": x.get("error")} for x in data.get("groups", [])]
receipt["pass"] = receipt["exit_code"] == 0 and not receipt["timed_out"] and receipt["input_unchanged"] and receipt.get("browser_summary", {}).get("pass") is True
(process_dir / "process-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
sys.exit(0 if receipt["pass"] else 1)
