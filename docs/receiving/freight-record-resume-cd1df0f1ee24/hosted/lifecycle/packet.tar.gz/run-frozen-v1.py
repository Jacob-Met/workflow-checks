import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path("/dev/shm/hamon-freight-lifecycle-receiving-cd1df0f1ee24")
out=root/"execution-v1";out.mkdir(exist_ok=False)
manifest=json.loads((root/"pre-execution-manifest.json").read_text())
for r in manifest["files"]:
 b=(root/r["path"]).read_bytes();assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"]
started=time.monotonic()
with (out/"stdout.txt").open("wb") as stdout,(out/"stderr.txt").open("wb") as stderr:
 p=subprocess.Popen([sys.executable,str(root/"receive_lifecycle_v1.py")],stdout=stdout,stderr=stderr,start_new_session=True)
 try:
  status=p.wait(timeout=210);timed_out=False
 except subprocess.TimeoutExpired:
  timed_out=True
  p.terminate()
  try: status=p.wait(timeout=5)
  except subprocess.TimeoutExpired: p.kill();status=p.wait(timeout=5)
def pin(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
receipt={"command":[sys.executable,str(root/"receive_lifecycle_v1.py")],"pid":p.pid,"exit_code":status,"timed_out":timed_out,"duration_seconds":time.monotonic()-started,"stdout":pin(out/"stdout.txt"),"stderr":pin(out/"stderr.txt"),"source_manifest":pin(root/"pre-execution-manifest.json")}
(out/"process.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
raise SystemExit(0 if status==0 and not timed_out else 1)
