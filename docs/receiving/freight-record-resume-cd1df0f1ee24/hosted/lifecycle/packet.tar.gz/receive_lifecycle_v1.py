#!/usr/bin/env python3
"""Independent mock-only receiving of exact reviewed lifecycle helpers."""
import contextlib, ctypes, hashlib, importlib.util, json, os, pathlib, selectors, signal, subprocess, sys, time, traceback
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT/"receive_browser_hosted-reviewed-v5.py"
EXPECTED="b9735d6efbfcbe62ca9d26d945be2798f91ed1addd08a34f948862fa9d291649"
REAL_KILLPG=os.killpg
def pin(p):
    b=p.read_bytes()
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def snap(pid):
    try:
        p=pathlib.Path("/proc")/str(pid); raw=(p/"stat").read_text()
        a=raw[raw.rfind(")")+2:].split()
        return {"pid":pid,"ppid":int(a[1]),"pgid":int(a[2]),"sid":int(a[3]),"state":a[0],"start_ticks":int(a[19]),"uid":p.stat().st_uid,
                "args":[x.decode() for x in (p/"cmdline").read_bytes().split(b"\0") if x]}
    except (FileNotFoundError,ProcessLookupError): return None
def group_rows(pgid):
    rows=[]
    for p in pathlib.Path("/proc").iterdir():
        if not p.name.isdigit(): continue
        try:
            raw=(p/"stat").read_text(); a=raw[raw.rfind(")")+2:].split()
            if int(a[2])==pgid:
                row=snap(int(p.name))
                if row: rows.append(row)
        except (FileNotFoundError,ProcessLookupError,PermissionError): pass
    return rows
def live(row): return row is not None and row["state"]!="Z"
def ready(pipe,seconds=3):
    selector=selectors.DefaultSelector(); selector.register(pipe,selectors.EVENT_READ)
    try:
        assert selector.select(seconds),"mock readiness timeout"
        return json.loads(pipe.readline())
    finally: selector.close()
class Fixture:
    def __init__(self,path):
        self.path=path; path.mkdir(exist_ok=False); self.registry={}; self.children={}; self.events=[]; self.signals=[]; self.calls=[]; self.cleanup=[]
    def register(self,pid,profile):
        row=snap(pid)
        assert live(row) and row["uid"]==os.getuid()
        assert row["pid"]==row["pgid"]==row["sid"]
        assert "--user-data-dir="+str(profile) in row["args"]
        self.registry[pid]={**row,"profile":str(profile)}
        return row
    def spawn(self,role="normal",label="target"):
        profile=self.path/(label+"-profile")
        cmd=[sys.executable,str(ROOT/"mock_process.py"),"--role",role,"--user-data-dir="+str(profile)]
        child_profile=self.path/(label+"-child-profile")
        if role=="node": cmd+=["--child-profile",str(child_profile)]
        p=subprocess.Popen(cmd,start_new_session=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        self.children[p.pid]=p
        r=ready(p.stdout)
        self.register(p.pid,profile)
        if role=="node": self.register(r["child"]["pid"],child_profile)
        return p,r
    def verify_target(self,pgid):
        assert pgid in self.registry,"signal target was not created and registered by this harness"
        for row in group_rows(pgid):
            expected=self.registry.get(row["pid"])
            assert expected and all(row[k]==expected[k] for k in ["pid","start_ticks","uid","pgid","sid"]),"group member ownership changed"
            if live(row): assert "--user-data-dir="+expected["profile"] in row["args"],"owned mock marker changed"
    def identity(self,pid,label="identity",changes=None):
        row=self.registry[pid]
        data={k:row[k] for k in ["pid","pgid","sid","start_ticks"]}
        data["profile"]=row["profile"]
        if changes: data.update(changes)
        path=self.path/(label+".json"); path.write_text(json.dumps(data)+"\n")
        return path
    def session(self,pid,identity=None,profile=None,event_fail=False):
        def emit(kind,**fields):
            self.events.append({"kind":kind,**fields})
            if event_fail: raise OSError("independent injected diagnostic sink failure")
        return mod.OwnedBrowserSession(pathlib.Path(profile or self.registry[pid]["profile"]),identity or self.identity(pid),emit,self.signals)
    @contextlib.contextmanager
    def guard(self,allowed,race=None):
        def checked(pgid,sig):
            self.calls.append({"pgid":pgid,"signal":int(sig),"allowed":pgid in allowed})
            assert pgid in allowed,"supervisor attempted an unrelated signal"
            self.verify_target(pgid)
            if race is not None: race(pgid,sig)
            return REAL_KILLPG(pgid,sig)
        assert os.killpg is REAL_KILLPG
        os.killpg=checked
        try: yield
        finally: os.killpg=REAL_KILLPG
    def cleanup_all(self):
        assert os.killpg is REAL_KILLPG
        for pid,row in reversed(list(self.registry.items())):
            current=snap(pid)
            if live(current):
                self.verify_target(row["pgid"])
                REAL_KILLPG(row["pgid"],signal.SIGTERM)
                end=time.monotonic()+.3
                while time.monotonic()<end and live(snap(pid)): time.sleep(.01)
                if live(snap(pid)):
                    self.verify_target(row["pgid"]); REAL_KILLPG(row["pgid"],signal.SIGKILL)
                self.cleanup.append({"pid":pid,"start_ticks":row["start_ticks"],"own_verified_cleanup":True})
        for p in self.children.values():
            p.wait(timeout=2)
            for stream in [p.stdin,p.stdout,p.stderr]:
                if stream: stream.close()
        for pid in self.registry:
            try: os.waitpid(pid,os.WNOHANG)
            except ChildProcessError: pass
        assert not any(live(snap(pid)) for pid in self.registry),"own fixture still live"
    def dump(self):
        return {"registered":list(self.registry.values()),"events":self.events,"signals":self.signals,"syscalls":self.calls,"cleanup":self.cleanup}
def registered_after_node_exit(f):
    node,r=f.spawn("node","node"); child=r["child"]["pid"]
    s=f.session(child); assert s.observe()
    node.stdin.write("\n"); node.stdin.flush(); assert node.wait(timeout=3)==0
    assert live(snap(child))
    with f.guard({child}): s.stop()
    assert not live(snap(child))
    assert any(x.get("delivered") is True for x in f.signals)
def sentinel_survives(f):
    target,_=f.spawn(); sentinel,_=f.spawn(label="different-profile-sentinel")
    before=snap(sentinel.pid); s=f.session(target.pid); s.observe()
    with f.guard({target.pid}): s.stop()
    after=snap(sentinel.pid)
    assert not live(snap(target.pid)) and live(after)
    assert all(after[k]==before[k] for k in ["pid","start_ticks","uid","pgid","sid"])
    assert not any(c["pgid"]==sentinel.pid for c in f.calls)
def mismatch_refused(f):
    target,_=f.spawn()
    actual=f.registry[target.pid]
    wrong=f.path/"wrong-profile"
    variants=[
        ("start",{"start_ticks":actual["start_ticks"]+1},None),
        ("declared-profile",{"profile":str(wrong)},actual["profile"]),
        ("live-profile",{"profile":str(wrong)},str(wrong))]
    for label,changes,profile in variants:
        identity=f.identity(target.pid,label,changes); s=f.session(target.pid,identity,profile)
        before=len(f.calls); refused=False
        try:
            with f.guard({target.pid}): s.stop()
        except AssertionError: refused=True
        assert refused and len(f.calls)==before and live(snap(target.pid)),label
def already_exited(f):
    target,_=f.spawn("pipe")
    s=f.session(target.pid); s.observe()
    target.stdin.write("\n"); target.stdin.flush(); assert target.wait(timeout=3)==0
    assert snap(target.pid) is None
    with f.guard({target.pid}): s.stop()
    assert not f.calls and s.after_cleanup==[]
def esrch_race(f):
    target,_=f.spawn("pipe")
    s=f.session(target.pid); s.observe()
    def race(pgid,sig):
        assert pgid==target.pid and sig==signal.SIGTERM
        target.stdin.write("\n"); target.stdin.flush(); assert target.wait(timeout=3)==0
        assert snap(target.pid) is None
    with f.guard({target.pid},race): s.stop()
    assert len(f.calls)==1
    assert any(x.get("already_empty") is True and x.get("delivered") is False for x in f.signals)
    assert s.after_cleanup==[]
def term_ignoring(f):
    target,_=f.spawn("ignore")
    s=f.session(target.pid); s.observe()
    with f.guard({target.pid}): s.stop()
    assert not live(snap(target.pid))
    assert [x["signal"] for x in f.calls]==[int(signal.SIGTERM),int(signal.SIGKILL)]
    assert all(x.get("delivered") is True for x in f.signals if x.get("target")=="browser-session")
def diagnostic_failure(f):
    target,_=f.spawn()
    s=f.session(target.pid,event_fail=True); s.observe()
    with f.guard({target.pid}): s.stop()
    assert not live(snap(target.pid))
    diagnostics=[x for x in f.signals if "diagnostic_error" in x]
    assert len(diagnostics)>=2 and any(x.get("delivered") is True for x in f.signals)
def deadline(*_): raise TimeoutError("independent25secondcontrol deadline")
assert pin(SOURCE)["sha256"]==EXPECTED
spec=importlib.util.spec_from_file_location("reviewed_supervisor",SOURCE)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,"own subreaper setup"
out=ROOT/"run-v1"; out.mkdir(exist_ok=False)
report={"format":"hamon-freight-independent-lifecycle-result/1","source":pin(SOURCE),"harness":pin(pathlib.Path(__file__)),"mock":pin(ROOT/"mock_process.py"),
        "contract":pin(ROOT/"contract-v1.json"),"addendum":pin(ROOT/"contract-addendum-v1.json"),"runtime":sys.version,"controls":[],"product_execution":False,"browser_execution":False}
signal.signal(signal.SIGALRM,deadline)
for name,fn in [("registered_group_after_node_exit",registered_after_node_exit),("unrelated_sentinel_survives",sentinel_survives),("identity_or_ownership_mismatch_refused",mismatch_refused),("verified_already_exited_group",already_exited),("disappearance_between_check_and_signal",esrch_race),("term_ignoring_owned_group",term_ignoring),("diagnostic_sink_failure_keeps_cleanup",diagnostic_failure)]:
    f=Fixture(out/name); row={"id":name,"pass":False}; started=time.monotonic()
    try:
        signal.alarm(25); fn(f); row["pass"]=True
    except BaseException: row["error"]=traceback.format_exc()
    finally:
        signal.alarm(0)
        try: f.cleanup_all()
        except BaseException: row["pass"]=False; row["cleanup_error"]=traceback.format_exc()
        row["duration_seconds"]=time.monotonic()-started
        if row["duration_seconds"]>30: row["pass"]=False; row["bound_exceeded"]=True
        row.update(f.dump()); report["controls"].append(row)
        (out/"receipt.partial.json").write_text(json.dumps(report,indent=2)+"\n")
        print(json.dumps({"id":name,"pass":row["pass"],"seconds":row["duration_seconds"],"error":row.get("error"),"cleanup_error":row.get("cleanup_error")}),flush=True)
    if not row["pass"]: break
report["source_unchanged"]=pin(SOURCE)==report["source"]
report["pass"]=len(report["controls"])==7 and all(x["pass"] for x in report["controls"]) and report["source_unchanged"]
report["passed"]=sum(x["pass"] for x in report["controls"])
report["failed"]=sum(not x["pass"] for x in report["controls"])
(out/"receipt.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"pass":report["pass"],"passed":report["passed"],"failed":report["failed"],"source_unchanged":report["source_unchanged"],"receipt":pin(out/"receipt.json")}),flush=True)
raise SystemExit(0 if report["pass"] else 1)
