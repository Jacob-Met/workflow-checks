#!/usr/bin/env python3
import argparse, json, os, pathlib, signal, subprocess, sys, time
ap=argparse.ArgumentParser()
ap.add_argument("--role", choices=["normal","ignore","pipe","node"], required=True)
ap.add_argument("--user-data-dir", required=True)
ap.add_argument("--child-profile")
args=ap.parse_args()
signal.signal(signal.SIGALRM, lambda *_: sys.exit(0))
signal.alarm(22)
if args.role=="ignore":
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
if args.role=="node":
    child=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).resolve()),"--role","normal","--user-data-dir="+args.child_profile],start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    child_ready=json.loads(child.stdout.readline())
    print(json.dumps({"pid":os.getpid(),"child":child_ready}),flush=True)
    sys.stdin.readline()
else:
    print(json.dumps({"pid":os.getpid(),"role":args.role}),flush=True)
    if args.role=="pipe": sys.stdin.readline()
    else:
        while True: time.sleep(.05)
