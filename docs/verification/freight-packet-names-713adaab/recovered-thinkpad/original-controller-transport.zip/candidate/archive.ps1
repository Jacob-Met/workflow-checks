$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Users\minec\AppData\Local\Temp\hamon-freight-packet-names-713adaab-fixed-87da595f4f5048d0bb28108ba7a7fbe3'
$zip=Join-Path $root 'candidate-custody.zip'
Compress-Archive -LiteralPath @((Join-Path $root 'evidence'),(Join-Path $root 'ordinary'),(Join-Path $root 'case-pair'),(Join-Path $root 'nul-device'),(Join-Path $root 'driver.stdout.txt'),(Join-Path $root 'driver.stderr.txt'),(Join-Path $root 'receiving-driver.py'),(Join-Path $root 'source-manifest.json'),(Join-Path $root 'baseline-report.json')) -DestinationPath $zip
[pscustomobject]@{path=$zip;bytes=(Get-Item -LiteralPath $zip).Length;sha256=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()} | ConvertTo-Json -Compress
