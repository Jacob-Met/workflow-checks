$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Users\minec\AppData\Local\Temp\hamon-freight-packet-names-713adaab-fixed-87da595f4f5048d0bb28108ba7a7fbe3'
$zip=Join-Path $root 'candidate-bundle.zip'
if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower() -ne 'bbc4619911ea9c347d2f75fb31fb9ad6579977327bd965e058c13036b967748f') {throw 'bundle hash mismatch'}
Expand-Archive -LiteralPath $zip -DestinationPath $root
$p=Start-Process -FilePath C:\Windows\py.exe -ArgumentList @('-3.11','-I','-S','-B','-X','utf8',(Join-Path $root 'receiving-driver.py')) -WorkingDirectory $root -Wait -PassThru -RedirectStandardOutput (Join-Path $root 'driver.stdout.txt') -RedirectStandardError (Join-Path $root 'driver.stderr.txt')
$code=$p.ExitCode
[pscustomobject]@{inner_returncode=$code;stdout=[string](Get-Content -LiteralPath (Join-Path $root 'driver.stdout.txt') -Raw);stderr=[string](Get-Content -LiteralPath (Join-Path $root 'driver.stderr.txt') -Raw)} | ConvertTo-Json -Compress
exit $code
