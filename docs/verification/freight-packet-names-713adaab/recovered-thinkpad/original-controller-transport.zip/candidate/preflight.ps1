$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Users\minec\AppData\Local\Temp\hamon-freight-packet-names-713adaab-fixed-87da595f4f5048d0bb28108ba7a7fbe3'
if ($env:COMPUTERNAME -ne 'DESKTOP-LA7CMTA') {throw 'unexpected host'}
if (Test-Path -LiteralPath $root) {throw 'namespace exists'}
New-Item -ItemType Directory -Path $root | Out-Null
[pscustomobject]@{host=$env:COMPUTERNAME;namespace=$root;drive_format=(Get-Volume -DriveLetter C).FileSystem;free_bytes=(Get-PSDrive C).Free;python=(& C:\Windows\py.exe -3.11 -V 2>&1 | Out-String).Trim()} | ConvertTo-Json -Compress
