$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root='C:\Users\minec\AppData\Local\Temp\hamon-freight-packet-names-713adaab-e2c62ff09de544df82ce01963ada15a5'
$zip=Join-Path $root 'source-bundle.zip'
if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower() -ne 'c39a34c0b59ad59c9be63761c98713d61a4a7926db1eb2c3584087fabd4b56a4') {throw 'bundle hash mismatch'}
Expand-Archive -LiteralPath $zip -DestinationPath $root
$p=Start-Process -FilePath C:\Windows\py.exe -ArgumentList @('-3.11','-I','-S','-B','-X','utf8',(Join-Path $root 'receiving-driver.py')) -WorkingDirectory $root -Wait -PassThru -RedirectStandardOutput (Join-Path $root 'driver.stdout.txt') -RedirectStandardError (Join-Path $root 'driver.stderr.txt')
$code=$p.ExitCode
[pscustomobject]@{inner_returncode=$code;stdout=(Get-Content -LiteralPath (Join-Path $root 'driver.stdout.txt') -Raw);stderr=(Get-Content -LiteralPath (Join-Path $root 'driver.stderr.txt') -Raw)} | ConvertTo-Json -Compress
exit $code
