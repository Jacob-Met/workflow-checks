# Independent freight review bundle receiving

## Decision

Accept **candidate v2** for the scoped native HTTP receiving contract. The unchanged independent verifier passes **10 of 10 methods**, with no failures or errors. Across 96 actual HTTP exchanges, it made 28 bundle requests: 11 successful ZIP downloads and 17 refusals. Every successful ZIP passed the complete snapshot checks, and every bundle request left all generated input and output file hashes unchanged. [Structured acceptance](receiving-verification.json), [raw v2 log](evidence/candidate-v2-receiving.log), and [HTTP/file observations](evidence/candidate-v2/observations.json) retain the results.

This review used the actual native `App`, HTTP handler, pipeline, and 24-load, seed-7 synthetic generator in an isolated directory. Expected packet bytes, selected report rows, saved decision/history, and hash inputs were derived independently from native files and responses. The producer's ZIP builder was not an oracle. The reviewer made no production-source edits.

## Source and verifier pins

Repository: `Jacob-Met/workflow-checks`. The receiving parent is commit `2f1e5f777197eedd69d51a4d81c0da744b65ad88`, tree `86e6201872d2f2400537b84a50f026a1335a8c3d`. The baseline contains 21 exact Git-blob-checked files; each candidate contains 23 frozen files. Eighteen inherited files are unchanged. Full bytes and pins are retained in `baseline/`, `candidate-v1/`, `candidate-v2/`, and their [source manifests](source-manifest.json).

| Accepted item | SHA-256 |
| --- | --- |
| `candidate-v2/freight_packets/freightpkt/web.py` | `ff4d2ef9dac9fa96e29525453a3dde1b4cf8d8852e62ec00d7e7c59b137719c7` |
| `candidate-v2/freight_packets/freightpkt/handoff.py` | `413290d887d045b96dd1639c34b9c769f0e730beb28dce06c654a0df36cf1a02` |
| `candidate-v2/freight_packets/freightpkt/ui.html` | `cdc52a196a480df2db210870487bab84e248cf69278fb27cefbc78a89b2ad0e3` |
| [Independent v2 source manifest](candidate-v2-manifest.json) | `1b708c929256ac737876354c155051ac6bb91bb7f848b0924e8a2554c780d5d2` |
| [Unchanged independent verifier](receive_handoff.py) | `78bb50f028c37e2a3abaecb76f496974a272ea0e517c203b95e3e504bf18fd8d` |
| [Acceptance receipt](receiving-verification.json) | `f0c410e2747958a29cb4850f73f9031f0ed78b958cca6228657fe632f29c4d3e` |

All 67 baseline/v1/v2 source-file hashes matched after execution. Eleven existing functions, including the evidence fingerprint, native decision view, decision writes, rerun/regeneration, and output access, retain identical source and AST. The structured acceptance lists each comparison. The accepted web file's Git blob is `e26f84ff9e0d3475c910f681d80e19256f70eccc`.

## Original absence, discovered failure, and repair

| Snapshot | Actual result | File effects |
| --- | --- | --- |
| Original parent | The proposed bundle URL returns 404 after a selected review and its history have been saved. Static original UI source contains none of the new route, control ID, or download label. | All input/output hashes unchanged. |
| Candidate v1 | Nine methods pass. With a saved link and then a missing generated `summary.json`, the download returns HTTP 200 with a 5,232-byte ZIP. | The GET recreates `out/summary.json` and changes `out/audit.jsonl`. |
| Candidate v2 | The same ten-method verifier passes. The same missing-summary case now returns 404. | No generated summary and no audit change; all 28 bundle requests are read-only. |

The baseline [native probe](baseline_probe.py), [actual HTTP receipt](evidence/baseline-probe.json), and [static UI absence receipt](evidence/baseline-ui-absence.json) distinguish runtime and source evidence; this reviewer did not execute a browser baseline. The [v1 counterexample](evidence/candidate-v1-missing-summary-counterexample.json), [failing ZIP](evidence/candidate-v1/test_missing_current_summary_is_refused_without_regenerating_outputs-4.zip), [raw failing log](evidence/candidate-v1-receiving.log), and full observations remain unchanged. The [v2 missing-summary receipt](evidence/candidate-v2-missing-summary-receipt.json) is an extract of the already completed passing run.

The producer repaired the backend with a three-line preflight inside the existing bundle lock. It refuses when the generated summary is unavailable, before calling the existing `summary()` method that can initialize the pipeline. The existing summary/bootstrap behavior remains unchanged. The producer separately repaired the restored unsaved-note UI state and owns its browser evidence.

## Receiving coverage

The ten methods check the following native behaviors:

1. A selected load's exact packet bytes, six selected report sections, saved review/history, all four manifest hashes, ZIP member names and modes, CRC, attachment headers, length, and no-store response.
2. A changed saved review invalidates the old review token even when evidence has not changed; a fresh link returns the exact replacement review.
3. Selected packet or report changes reject stale evidence tokens; fresh snapshots truthfully show the old review as stale.
4. Changes to another load's review or report rows, or run metadata alone, leave the selected bundle payloads unchanged. Other-load notes and decisions stay out of the export.
5. Native unreviewed, unbound, cleared, and rejected states retain their meaning without fabricating an approval or a review file.
6. Missing packet and unknown load requests return 404.
7. Missing, empty, or repeated required query fields return 400.
8. Combining another load's evidence or review token with the selected load returns 409.
9. Accepted Unicode, HTML-like, and lone-surrogate saved notes/history remain exact in JSON and produce escaped, readable UTF-8 cover text.
10. A missing generated summary returns 404 without invoking generation or changing the audit log.

The evidence fingerprint keeps the existing compact sorted JSON/UTF-8 recipe with `ensure_ascii=False`. The new opaque review token is checked against compact sorted JSON with `ensure_ascii=True`, preserving the native saved view. The selected snapshot checks do not treat a draft bundle as a payment instruction. All 23 actual ZIP responses from the v1 and v2 runs are retained, including the failed v1 download.

## Replay and publication layout

The verifier uses Python 3.12.14's standard library; it needs no installed package. From a **fresh extracted copy** of this review packet, run:

```sh
mkdir -p tmp
PYTHONDONTWRITEBYTECODE=1 TMPDIR="$PWD/tmp" \
FREIGHT_REVIEW_SOURCE="$PWD/candidate-v2/freight_packets" \
FREIGHT_REVIEW_ARTIFACTS="$PWD/replay-new" \
python3 -B receive_handoff.py
```

Use explicit source and a fresh output directory: the unchanged verifier retains its original v1 defaults so replay must not overwrite historical observations. To reproduce the held failure, select `candidate-v1/freight_packets` and a different fresh output directory. The original `baseline_probe.py` likewise belongs in a fresh extracted copy when replayed.

`handoff-manifest.json` is the exact file whitelist for inclusion once in the producer's combined evidence archive. Keep historical source trees and their `test_*.py` files inside that archive. A directly reviewable verifier should retain the noncollectible filename `receive_handoff.py` outside `tests/`.

A source-receipt write was interrupted by exhausted shared temporary storage after the behavioral run. The empty interrupted artifact and operational receipt are preserved; that invocation executed no behavioral test. Byte-preserving hardlink deduplication touched only the reviewer's own files. The original paths and hashes remain intact.

This qualification covers one local native server and the exact pinned sources. The producer owns the separately reported retained-suite and browser results; they are not counted in these ten methods. Root owns fresh-parent compatibility, publication, CI, and merge. No further test expansion is proposed.
