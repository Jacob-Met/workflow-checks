"""Independent native HTTP reproduction of the missing per-load handoff."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import threading
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE = HERE / "baseline" / "freight_packets"
sys.path.insert(0, str(SOURCE))
from freightpkt.pipeline import run
from freightpkt.synth import generate
from freightpkt.web import App, make_handler


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(root):
    return {str(p.relative_to(root)): sha(p.read_bytes())
            for p in sorted(root.rglob("*")) if p.is_file()}


def main():
    with tempfile.TemporaryDirectory(prefix="baseline-http-", dir=HERE / "tmp") as temporary:
        work = Path(temporary)
        data, out = work / "data", work / "out"
        generate(data, n_loads=24, seed=7)
        run(data, out, run_by="independent-handoff-baseline")
        app = App(data, out)
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.server_address[1])
        exchanges = []

        def request(path, body=None):
            request = Request(base + path,
                              data=None if body is None else json.dumps(body).encode(),
                              headers={"Content-Type": "application/json"})
            try:
                response = urlopen(request, timeout=5)
            except HTTPError as error:
                response = error
            with response:
                payload = response.read()
                record = {"method": request.get_method(), "path": path,
                          "status": response.status, "headers": dict(response.headers),
                          "body_sha256": sha(payload), "body_bytes": len(payload)}
                exchanges.append(record)
                parsed = json.loads(payload) if response.headers.get_content_type() == "application/json" else payload
                return response.status, parsed, payload

        try:
            status, summary, _ = request("/api/summary")
            if status != 200:
                raise RuntimeError("native baseline summary did not load")
            selected, other = [p["load_id"] for p in summary["packets"][:2]]
            for load_id, decision, note in [
                (selected, "adjust", "SELECTED prior adjustment"),
                (other, "reject", "OTHER_LOAD_PRIVATE_REVIEW_91af"),
                (selected, "approve", "SELECTED current saved review"),
            ]:
                status, _, _ = request("/api/decision", {
                    "load_id": load_id, "decision": decision, "note": note,
                    "evidence_version": summary["evidence_versions"][load_id],
                })
                if status != 200:
                    raise RuntimeError("native baseline decision did not save")
            _, summary, _ = request("/api/summary")
            review = summary["decisions"][selected]
            review_version = sha(json.dumps(review, sort_keys=True, separators=(",", ":"),
                                            ensure_ascii=True, allow_nan=False).encode("ascii"))
            query = urlencode({"load_id": selected,
                               "evidence_version": summary["evidence_versions"][selected],
                               "review_version": review_version})
            before = snapshot(work)
            status, _, payload = request("/api/review-bundle?" + query)
            after = snapshot(work)
            artifact = HERE / "evidence" / "baseline-selected-packet.html"
            packet = next(p for p in summary["packets"] if p["load_id"] == selected)
            shutil.copyfile(out / packet["file"], artifact)
            report = {
                "receiving_commit": "2f1e5f777197eedd69d51a4d81c0da744b65ad88",
                "source_web_sha256": sha((SOURCE / "freightpkt" / "web.py").read_bytes()),
                "fixture": {"generator": "pinned native freightpkt.synth.generate", "loads": 24, "seed": 7},
                "selected_load": selected, "other_load": other,
                "selected_saved_view": review,
                "other_saved_view": summary["decisions"][other],
                "planned_download_status": status,
                "planned_download_body": payload.decode("utf-8"),
                "feature_requirement_met": status == 200 and payload.startswith(b"PK"),
                "all_input_output_files_unchanged_by_download": before == after,
                "files_before": before, "files_after": after,
                "selected_packet_sha256": sha(artifact.read_bytes()),
                "http_exchanges": exchanges,
            }
            (HERE / "evidence" / "baseline-probe.json").write_text(json.dumps(report, indent=2) + "\n")
            print(json.dumps({key: report[key] for key in (
                "receiving_commit", "selected_load", "planned_download_status",
                "feature_requirement_met", "all_input_output_files_unchanged_by_download")}, indent=2))
            return 0 if report["feature_requirement_met"] else 1
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)


if __name__ == "__main__":
    raise SystemExit(main())
