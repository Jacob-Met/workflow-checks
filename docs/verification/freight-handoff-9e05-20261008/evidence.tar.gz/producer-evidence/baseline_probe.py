from __future__ import annotations
import hashlib
import json
import sys
import tempfile
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import urlopen

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from freightpkt.pipeline import run
from freightpkt.synth import generate
from freightpkt.web import App, make_handler

with tempfile.TemporaryDirectory(prefix="freight-handoff-baseline-", dir=Path(__file__).parent) as temp:
    root = Path(temp)
    data, out = root / "data", root / "out"
    generate(data, n_loads=24, seed=7)
    run(data, out)
    app = App(data, out)
    summary = app.summary()
    selected = summary["packets"][0]["load_id"]
    app.decide({"load_id": selected, "decision": "approve", "note": "Selected-load saved review", "evidence_version": summary["evidence_versions"][selected]})
    summary = app.summary()
    before = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    query = urlencode({"load_id": selected, "evidence_version": summary["evidence_versions"][selected],
        "review_version": hashlib.sha256(json.dumps(summary["decisions"][selected],sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()})
    try:
        try:
            with urlopen(f"http://127.0.0.1:{server.server_port}/api/review-bundle?{query}", timeout=5) as response:
                status, body = response.status, response.read()
        except HTTPError as error:
            status, body = error.code, error.read()
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    after = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}
    ui = (Path(sys.argv[1]) / "freightpkt/ui.html").read_text()
    report = {"source_root": str(Path(sys.argv[1]).resolve()), "selected_load": selected,
        "evidence_version": summary["evidence_versions"][selected],
        "saved_review": summary["decisions"][selected],
        "native_http_status": status, "response_text": body.decode(errors="replace"),
        "expected_download_status": 200, "download_control_present": 'id="download-review-bundle"' in ui,
        "data_and_output_unchanged_by_get": before == after,
        "source_pipeline_generated_synthetic_inputs": True,
        "feature_available": status == 200 and 'id="download-review-bundle"' in ui}
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["feature_available"] else 1)

